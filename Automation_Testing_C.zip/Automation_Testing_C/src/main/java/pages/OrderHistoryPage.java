package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page Object for Order History functionality.
 * Provides methods to interact with the Orders page and verify order history.
 */
public class OrderHistoryPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // Orders navigation link locators
    private final By ordersLink = By.cssSelector("a[href*='order'], a[href*='orders'], [id*='order'], [id*='orders']");
    private final By ordersButton = By.cssSelector("button[id*='order'], button[id*='orders']");

    // Order history page locators
    private final By orderHistoryPage = By.cssSelector(".orders-page, .order-history, [class*='order'][class*='page'], [class*='order'][class*='history']");
    private final By orderList = By.cssSelector(".order-list, .orders-list, [class*='order'][class*='list']");
    private final By orderTable = By.cssSelector("table[class*='order'], .order-table, [class*='order'][class*='table']");
    private final By orderItem = By.cssSelector(".order-item, .order-row, [class*='order'][class*='item']");
    private final By orderCard = By.cssSelector(".order-card, [class*='order'][class*='card']");

    // No orders message locators
    private final By noOrdersMessage = By.xpath("//*[contains(text(),'No orders') or contains(text(),'No Order') or contains(text(),'no orders') or contains(text(),'no order') or contains(text(),'empty') or contains(text(),'not found')]");

    public OrderHistoryPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // =========================
    // Orders Navigation Link Methods
    // =========================

    /**
     * Checks whether the Orders navigation link exists in the DOM.
     *
     * @return true if the Orders link is present in the DOM
     */
    public boolean isOrdersLinkPresent() {
        try {
            // Try to find either a link or button for orders
            List<WebElement> links = driver.findElements(ordersLink);
            List<WebElement> buttons = driver.findElements(ordersButton);
            return !links.isEmpty() || !buttons.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Orders navigation link is visible.
     *
     * @return true if the Orders link is displayed
     */
    public boolean isOrdersLinkVisible() {
        try {
            // Try link first
            List<WebElement> links = driver.findElements(ordersLink);
            for (WebElement link : links) {
                if (link.isDisplayed()) {
                    return true;
                }
            }
            // Try button if no visible link found
            List<WebElement> buttons = driver.findElements(ordersButton);
            for (WebElement button : buttons) {
                if (button.isDisplayed()) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Orders navigation link is enabled.
     *
     * @return true if the Orders link is enabled and clickable
     */
    public boolean isOrdersLinkEnabled() {
        try {
            // Try link first
            List<WebElement> links = driver.findElements(ordersLink);
            for (WebElement link : links) {
                if (link.isDisplayed() && link.isEnabled()) {
                    return true;
                }
            }
            // Try button if no enabled link found
            List<WebElement> buttons = driver.findElements(ordersButton);
            for (WebElement button : buttons) {
                if (button.isDisplayed() && button.isEnabled()) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clicks the Orders navigation link.
     * Uses explicit wait to ensure the element is clickable.
     */
    public void clickOrders() {
        // Try link first
        List<WebElement> links = driver.findElements(ordersLink);
        for (WebElement link : links) {
            if (link.isDisplayed() && link.isEnabled()) {
                wait.until(ExpectedConditions.elementToBeClickable(ordersLink)).click();
                return;
            }
        }
        // Try button if no clickable link found
        wait.until(ExpectedConditions.elementToBeClickable(ordersButton)).click();
    }

    // =========================
    // Order History Page Methods
    // =========================

    /**
     * Waits for the Order History page to load completely.
     * Uses explicit wait for the page container to be visible.
     */
    public void waitForOrdersPage() {
        // Wait for either the order history page container or order list/table to be visible
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(orderHistoryPage),
                ExpectedConditions.visibilityOfElementLocated(orderList),
                ExpectedConditions.visibilityOfElementLocated(orderTable)
        ));
    }

    /**
     * Checks whether the Order History page is displayed.
     *
     * @return true if the Order History page is visible
     */
    public boolean isOrdersPageDisplayed() {
        try {
            // Check for order history page container
            if (driver.findElements(orderHistoryPage).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for order list
            if (driver.findElements(orderList).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for order table
            if (driver.findElements(orderTable).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check URL for orders page
            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("order") || currentUrl.contains("orders")) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether an order list or order table is present on the page.
     *
     * @return true if an order list or table is displayed
     */
    public boolean isOrderListDisplayed() {
        try {
            // Check for order list
            if (driver.findElements(orderList).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for order table
            if (driver.findElements(orderTable).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for order items/cards
            if (driver.findElements(orderItem).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            if (driver.findElements(orderCard).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the count of displayed orders.
     *
     * @return the number of visible order items
     */
    public int getDisplayedOrderCount() {
        try {
            // Count order items
            List<WebElement> items = driver.findElements(orderItem);
            if (!items.isEmpty()) {
                return (int) items.stream().filter(WebElement::isDisplayed).count();
            }
            // Count order cards
            List<WebElement> cards = driver.findElements(orderCard);
            if (!cards.isEmpty()) {
                return (int) cards.stream().filter(WebElement::isDisplayed).count();
            }
            // Count table rows (excluding header)
            List<WebElement> rows = driver.findElements(By.cssSelector("table[class*='order'] tbody tr, .order-table tbody tr"));
            if (!rows.isEmpty()) {
                return (int) rows.stream().filter(WebElement::isDisplayed).count();
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Checks whether at least one order exists in the order history.
     *
     * @return true if there is at least one order displayed
     */
    public boolean hasOrders() {
        return getDisplayedOrderCount() > 0;
    }

    /**
     * Checks whether a "No orders" or empty state message is displayed.
     *
     * @return true if a no-orders message is visible
     */
    public boolean isNoOrdersMessageDisplayed() {
        try {
            List<WebElement> messages = driver.findElements(noOrdersMessage);
            return messages.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the text of the "No orders" message if displayed.
     *
     * @return the message text, or empty string if not found
     */
    public String getNoOrdersMessage() {
        try {
            List<WebElement> messages = driver.findElements(noOrdersMessage);
            for (WebElement message : messages) {
                if (message.isDisplayed()) {
                    return message.getText().trim();
                }
            }
        } catch (Exception e) {
            // Ignore exceptions
        }
        return "";
    }

    /**
     * Waits for the document to be fully loaded and the order history to render.
     * Uses JavaScript to check document ready state.
     */
    public void waitForPageLoad() {
        wait.until(d -> {
            JavascriptExecutor js = (JavascriptExecutor) d;
            return "complete".equals(js.executeScript("return document.readyState"));
        });
    }

    // =========================
    // Order Detail Validation Methods
    // =========================

    /**
     * Locates an order element by its Order ID.
     * Searches through all displayed elements for one that contains the specified
     * order ID text. Uses multiple fallback strategies to handle different order
     * history page layouts (including BrowserStack Demo), and also tries searching
     * for the numeric portion of the order ID (e.g., searching for "101" if "#101"
     * was requested) as order IDs may be displayed without the "#" prefix.
     *
     * @param orderId the order ID to search for (e.g., "#101" or "101")
     * @return the WebElement representing the order, or null if not found
     */
    public WebElement getOrderById(String orderId) {
        // Also search for just the numeric part if orderId contains a # prefix (e.g., "#101" -> "101")
        String numericOrderId = orderId.replaceAll("^#", "");
        String[] searchPatterns = (numericOrderId.equals(orderId))
                ? new String[]{orderId}
                : new String[]{orderId, numericOrderId};

        for (String searchText : searchPatterns) {
            WebElement result = findElementContainingText(searchText);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    /**
     * Attempts to find a visible element on the page that contains the given text.
     * Tries progressively broader search strategies.
     *
     * @param searchText the text to search for within elements
     * @return the first matching visible WebElement, or null if not found
     */
    private WebElement findElementContainingText(String searchText) {
        try {
            // Strategy 1: Common order item/card/row selectors
            List<WebElement> items = driver.findElements(orderItem);
            if (items.isEmpty()) {
                items = driver.findElements(orderCard);
            }
            if (items.isEmpty()) {
                items = driver.findElements(By.cssSelector("table[class*='order'] tbody tr, .order-table tbody tr"));
            }
            for (WebElement item : items) {
                if (item.isDisplayed() && item.getText().contains(searchText)) {
                    return item;
                }
            }

            // Strategy 2: Containers with "order" in class name, list items, cards, table rows
            List<WebElement> containers = driver.findElements(
                By.cssSelector("[class*='order'], li, .item, .card, tr, div[class*='row']"));
            for (WebElement container : containers) {
                if (container.isDisplayed() && container.getText().contains(searchText)) {
                    return container;
                }
            }

            // Strategy 3: Any visible table row
            List<WebElement> allRows = driver.findElements(By.cssSelector("table tr"));
            for (WebElement row : allRows) {
                if (row.isDisplayed() && row.getText().contains(searchText)) {
                    return row;
                }
            }

            // Strategy 4: XPath text-based search (most flexible fallback)
            // Searches for any element that contains the exact text
            List<WebElement> xpathResults = driver.findElements(
                By.xpath("//*[contains(text(),'" + searchText + "')]"));
            for (WebElement el : xpathResults) {
                if (el.isDisplayed()) {
                    return el;
                }
            }

            // Strategy 5: Any visible container/div/section/article on the page
            List<WebElement> allElements = driver.findElements(
                By.cssSelector("div, section, article, li, td, span, p, h1, h2, h3, h4, h5, h6"));
            for (WebElement el : allElements) {
                if (el.isDisplayed() && el.getText().contains(searchText)) {
                    return el;
                }
            }
        } catch (Exception e) {
            // Return null if not found
        }
        return null;
    }

    /**
     * Checks whether a specific order is displayed on the Order History page.
     *
     * @param orderId the order ID to check for (e.g., "#101")
     * @return true if the order is displayed, false otherwise
     */
    public boolean isOrderDisplayed(String orderId) {
        return getOrderById(orderId) != null;
    }

    /**
     * Retrieves the displayed Order ID from an order element.
     * Searches for text matching an order ID pattern (e.g., "#101") within the element.
     *
     * @param orderElement the order WebElement to extract the ID from
     * @return the Order ID text, or empty string if not found
     */
    public String getOrderId(WebElement orderElement) {
        try {
            // Look for the order ID in child elements that may contain it
            List<WebElement> idElements = orderElement.findElements(
                By.cssSelector("[class*='order-id'], [class*='orderId'], [class*='id'], th, td, strong, b, span, h1, h2, h3, h4, h5, h6"));
            for (WebElement el : idElements) {
                String text = el.getText().trim();
                if (text.matches(".*#\\d+.*")) {
                    return text;
                }
            }
            // Fallback: return the full text and extract the ID part
            String fullText = orderElement.getText();
            String[] lines = fullText.split("\\n");
            for (String line : lines) {
                line = line.trim();
                if (line.matches(".*#\\d+.*")) {
                    return line;
                }
            }
        } catch (Exception e) {
            // Return empty string
        }
        return "";
    }

    /**
     * Retrieves the displayed Order Date from an order element.
     * Searches for date-pattern text (e.g., "2024-01-15", "Jan 15, 2024") within the element.
     *
     * @param orderElement the order WebElement to extract the date from
     * @return the Order Date text, or empty string if not found
     */
    public String getOrderDate(WebElement orderElement) {
        try {
            // Look for date elements
            List<WebElement> dateElements = orderElement.findElements(
                By.cssSelector("[class*='date'], [class*='time'], td, th, span, p, div, small"));
            for (WebElement el : dateElements) {
                String text = el.getText().trim();
                if (text.matches(".*\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*") ||
                    text.matches(".*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \\d{1,2},? \\d{4}.*") ||
                    text.matches(".*\\d{1,2}[-/]\\d{1,2}[-/]\\d{4}.*")) {
                    return text;
                }
            }
            // Fallback: search lines in the element text
            String fullText = orderElement.getText();
            String[] lines = fullText.split("\\n");
            for (String line : lines) {
                line = line.trim();
                if (line.matches(".*\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*") ||
                    line.matches(".*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \\d{1,2},? \\d{4}.*") ||
                    line.matches(".*\\d{1,2}[-/]\\d{1,2}[-/]\\d{4}.*")) {
                    return line;
                }
            }
        } catch (Exception e) {
            // Return empty string
        }
        return "";
    }

    /**
     * Retrieves the displayed Order Price from an order element.
     * Searches for currency-pattern text (e.g., "$123.45", "USD 123.45") within the element.
     *
     * @param orderElement the order WebElement to extract the price from
     * @return the Order Price text, or empty string if not found
     */
    public String getOrderPrice(WebElement orderElement) {
        try {
            // Look for price elements
            List<WebElement> priceElements = orderElement.findElements(
                By.cssSelector("[class*='price'], [class*='total'], [class*='amount'], td, th, span, p, div, strong, b"));
            for (WebElement el : priceElements) {
                String text = el.getText().trim();
                if (text.matches(".*[£$€¥]\\s*\\d+(?:\\.\\d{1,2})?.*") ||
                    text.matches(".*\\d+(?:\\.\\d{1,2})?\\s*[£$€¥].*")) {
                    return text;
                }
            }
            // Fallback: search lines in the element text
            String fullText = orderElement.getText();
            String[] lines = fullText.split("\\n");
            for (String line : lines) {
                line = line.trim();
                if (line.matches(".*[£$€¥]\\s*\\d+(?:\\.\\d{1,2})?.*") ||
                    line.matches(".*\\d+(?:\\.\\d{1,2})?\\s*[£$€¥].*") ||
                    line.matches(".*(?:USD|EUR|GBP)\\s*\\d+(?:\\.\\d{1,2})?.*")) {
                    return line;
                }
            }
        } catch (Exception e) {
            // Return empty string
        }
        return "";
    }

    /**
     * Checks whether the order price in an order element is correctly formatted
     * as a currency value (e.g., starts with a currency symbol, followed by a number).
     *
     * @param orderElement the order WebElement to check price formatting on
     * @return true if the price is present and correctly formatted
     */
    public boolean isOrderPriceFormatted(WebElement orderElement) {
        String price = getOrderPrice(orderElement);
        if (price == null || price.isEmpty()) {
            return false;
        }
        // Validate price format: currency symbol + number with optional decimal
        // e.g., "$100", "$100.00", "£50.99"
        return price.matches(".*[£$€¥]\\s*\\d+(?:\\.\\d{1,2})?.*") ||
               price.matches(".*\\d+(?:\\.\\d{1,2})?\\s*[£$€¥].*") ||
               price.matches(".*(?:USD|EUR|GBP)\\s*\\d+(?:\\.\\d{1,2})?.*");
    }
}
