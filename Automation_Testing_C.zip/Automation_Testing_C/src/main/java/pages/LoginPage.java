package pages;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private final WebDriver driver;
    private final By signInForm = By.cssSelector("form");
    private final By signInLink = By.id("signin");
    private final By loginButton = By.id("login-btn");
    private final By logoutLink = By.id("logout");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isDisplayed() {
        return new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.or(
                        ExpectedConditions.urlContains("signin"),
                        ExpectedConditions.urlContains("login"),
                        ExpectedConditions.visibilityOfElementLocated(signInForm)));
    }

    /**
     * Clicks the "Sign In" link to navigate to the login page.
     */
    public void clickSignIn() {
        // Navigate directly to the signin page instead of clicking a link
        driver.get("https://bstackdemo.com/signin");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(signInForm));
    }

    /**
     * Selects a value from a React-Select dropdown. Uses keyboard interaction
     * by clicking the control, then sending keystrokes to the input element
     * to trigger React-Select's filtering and selection.
     *
     * @param fieldId the HTML id of the React-Select container (e.g., "username" or "password")
     * @param value   the text value to select
     */
    private void selectFromReactSelect(String fieldId, String value) {
        // Click the control to open the React-Select dropdown menu
        By control = By.cssSelector("#" + fieldId + " div[class*='control']");
        WebElement controlElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(control));
        controlElement.click();

        // Find the actual input element inside the React-Select
        // The input is automatically focused when the control is clicked
        By inputLocator = By.cssSelector("#" + fieldId + " input");
        WebElement inputElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(inputLocator));

        // Use Actions to move to the input and click to ensure focus
        Actions actions = new Actions(driver);
        actions.moveToElement(inputElement).click().perform();

        // Type the value and press ENTER to select the first matching option
        inputElement.sendKeys(value + Keys.ENTER);

        // Wait for the dropdown menu to close (selection confirmed)
        By menuLocator = By.cssSelector("#" + fieldId + " div[class*='menu']");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(menuLocator));
    }

    /**
     * Selects a username from the username dropdown on the sign-in page.
     *
     * @param username the username to select
     */
    public void selectUsername(String username) {
        selectFromReactSelect("username", username);
    }

    /**
     * Selects a password from the password dropdown on the sign-in page.
     *
     * @param password the password to select
     */
    public void selectPassword(String password) {
        selectFromReactSelect("password", password);
    }

    /**
      * Enters arbitrary username text into the username field.
      * This method is used for testing username case sensitivity where the username
      * value may not be in the predefined dropdown options.
      *
      * @param username the username text to enter
      */
    public void enterUsername(String username) {
        // Click the control to open the React-Select dropdown menu
        By control = By.cssSelector("#username div[class*='control']");
        WebElement controlElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(control));
        controlElement.click();

        // Find the actual input element inside the React-Select
        By inputLocator = By.cssSelector("#username input");
        WebElement inputElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(inputLocator));

        // Use Actions to move to the input and click to ensure focus
        Actions actions = new Actions(driver);
        actions.moveToElement(inputElement).click().perform();

        // Clear any existing value and type the username
        inputElement.sendKeys(Keys.CONTROL + "a");
        inputElement.sendKeys(Keys.DELETE);
        inputElement.sendKeys(username);

        // Press ENTER to attempt selection (or just close the dropdown)
        inputElement.sendKeys(Keys.ENTER);

        // Wait for the dropdown menu to close
        By menuLocator = By.cssSelector("#username div[class*='menu']");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(menuLocator));
    }

    /**
      * Enters arbitrary password text into the password field.
      * This method is used for testing password case sensitivity where the password
      * value may not be in the predefined dropdown options.
      *
      * @param password the password text to enter
      */
    public void enterPassword(String password) {
        // Click the control to open the React-Select dropdown menu
        By control = By.cssSelector("#password div[class*='control']");
        WebElement controlElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(control));
        controlElement.click();

        // Find the actual input element inside the React-Select
        By inputLocator = By.cssSelector("#password input");
        WebElement inputElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(inputLocator));

        // Use Actions to move to the input and click to ensure focus
        Actions actions = new Actions(driver);
        actions.moveToElement(inputElement).click().perform();

        // Clear any existing value and type the password
        inputElement.sendKeys(Keys.CONTROL + "a");
        inputElement.sendKeys(Keys.DELETE);
        inputElement.sendKeys(password);

        // Press ENTER to attempt selection (or just close the dropdown)
        inputElement.sendKeys(Keys.ENTER);

        // Wait for the dropdown menu to close
        By menuLocator = By.cssSelector("#password div[class*='menu']");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(menuLocator));
    }

    /**
     * Types arbitrary username text into the username React-Select field
     * WITHOUT pressing ENTER (which would trigger option creation/selection).
     * Uses ESC to close the dropdown after typing, preserving the typed text
     * without selecting any option.
     *
     * @param username the username text to type (including any whitespace)
     */
    public void typeUsername(String username) {
        // Click the control to open the React-Select dropdown menu
        By control = By.cssSelector("#username div[class*='control']");
        WebElement controlElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(control));
        controlElement.click();

        // Find the actual input element inside the React-Select
        By inputLocator = By.cssSelector("#username input");
        WebElement inputElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(inputLocator));

        // Use Actions to move to the input and click to ensure focus
        Actions actions = new Actions(driver);
        actions.moveToElement(inputElement).click().perform();

        // Clear any existing value and type the username
        inputElement.sendKeys(Keys.CONTROL + "a");
        inputElement.sendKeys(Keys.DELETE);
        inputElement.sendKeys(username);

        // Press ESC to close the dropdown without selecting any option
        // This preserves the typed text (including trailing whitespace)
        // and prevents React-Select from creating/selecting an option
        inputElement.sendKeys(Keys.ESCAPE);

        // Wait for the dropdown menu to close
        By menuLocator = By.cssSelector("#username div[class*='menu']");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(menuLocator));
    }

    /**
     * Types arbitrary password text into the password React-Select field
     * WITHOUT pressing ENTER (which would trigger option creation/selection).
     * Uses ESC to close the dropdown after typing, preserving the typed text
     * without selecting any option.
     *
     * @param password the password text to type (including any whitespace)
     */
    public void typePassword(String password) {
        // Click the control to open the React-Select dropdown menu
        By control = By.cssSelector("#password div[class*='control']");
        WebElement controlElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(control));
        controlElement.click();

        // Find the actual input element inside the React-Select
        By inputLocator = By.cssSelector("#password input");
        WebElement inputElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(inputLocator));

        // Use Actions to move to the input and click to ensure focus
        Actions actions = new Actions(driver);
        actions.moveToElement(inputElement).click().perform();

        // Clear any existing value and type the password
        inputElement.sendKeys(Keys.CONTROL + "a");
        inputElement.sendKeys(Keys.DELETE);
        inputElement.sendKeys(password);

        // Press ESC to close the dropdown without selecting any option
        // This preserves the typed text (including trailing whitespace)
        // and prevents React-Select from creating/selecting an option
        inputElement.sendKeys(Keys.ESCAPE);

        // Wait for the dropdown menu to close
        By menuLocator = By.cssSelector("#password div[class*='menu']");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(menuLocator));
    }

    /**
     * Clicks the "Log In" button to submit the login form.
     */
    public void clickLoginButton() {
        WebElement button = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(loginButton));
        button.click();
        // Wait for the page to navigate away from the signin page
        // The URL will change from /signin to / after successful login
        // Note: The URL may be https://bstackdemo.com/ or https://bstackdemo.com/?signin=true
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.or(
                        ExpectedConditions.urlToBe("https://bstackdemo.com/"),
                        ExpectedConditions.urlToBe("https://bstackdemo.com/?signin=true")));
    }

    /**
     * Performs a full login flow with the given credentials.
     *
     * @param username the username to log in with
     * @param password the password to log in with
     */
    public void login(String username, String password) {
        clickSignIn();
        // Wait for sign-in page to fully render before interacting with form elements
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        selectUsername(username);
        selectPassword(password);
        clickLoginButton();
    }

    /**
     * Performs login using the default demo account credentials.
     * Credentials can be overridden via system properties:
     *   -Ddemo.username=your_username -Ddemo.password=your_password
     */
    public void loginAsExistingUser() {
        String username = System.getProperty("demo.username", "demouser");
        String password = System.getProperty("demo.password", "testingisfun99");
        login(username, password);
    }

    /**
     * Waits until the login completes successfully by checking for indicators of a logged-in state.
     * On bstackdemo.com, after login the signin link disappears and a user indicator appears.
     */
    public void waitForSuccessfulLogin() {
        new WebDriverWait(driver, Duration.ofSeconds(15))
                .until(ExpectedConditions.or(
                        // The signin link should disappear after login
                        ExpectedConditions.invisibilityOfElementLocated(signInLink),
                        // A user name/dropdown indicator appears after login
                        ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".username, .user-name, [class*='user'], .nav-item")))
                );
    }

    /**
     * Checks whether the user is currently logged in by verifying the user is no longer
     * on the signin page.
     * On bstackdemo.com, after successful login the URL navigates away from /signin
     * back to the main page (with or without the ?signin=true query parameter).
     *
     * @return true if the user is logged in, false otherwise
     */
    public boolean isLoggedIn() {
        try {
            // After successful login on bstackdemo.com, the URL is no longer on /signin
            // The clickLoginButton() method already waits for navigation away from /signin
            String currentUrl = driver.getCurrentUrl();
            String urlPath = currentUrl.replaceAll("\\?.*$", "");
            return !urlPath.contains("/signin");
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Logout Methods
    // =========================

    /**
     * Clicks the logout link/button to sign out the current user.
     * Note: This method only performs the click action. Use waitForSuccessfulLogout()
     * to wait for the logout to complete.
     */
    public void logout() {
        // Try the standard logout locator (#logout) first
        List<WebElement> logoutElements = driver.findElements(logoutLink);
        if (!logoutElements.isEmpty() && logoutElements.get(0).isDisplayed()) {
            WebElement logoutElement = logoutElements.get(0);
            try {
                logoutElement.click();
            } catch (Exception e) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", logoutElement);
            }
            return;
        }

        // Fallback: some UIs show logout as a menu item - try to open user menu first
        By userMenu = By.cssSelector(".username, .user-name, [class*='user']");
        List<WebElement> menuElements = driver.findElements(userMenu);
        if (!menuElements.isEmpty() && menuElements.get(0).isDisplayed()) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", menuElements.get(0));
            // Small wait for the dropdown menu to appear
            try {
                Thread.sleep(500);
            } catch (InterruptedException ignored) {
            }
        }

        // Try logout menu item locators
        By logoutMenuItem1 = By.xpath("//*[self::a or self::button][contains(translate(., 'LOGOUT', 'logout'), 'logout')]");
        By logoutMenuItem2 = By.cssSelector("[class*='logout'] a, [class*='logout'] button");

        List<WebElement> logoutItems1 = driver.findElements(logoutMenuItem1);
        if (!logoutItems1.isEmpty() && logoutItems1.get(0).isDisplayed()) {
            logoutItems1.get(0).click();
            return;
        }

        List<WebElement> logoutItems2 = driver.findElements(logoutMenuItem2);
        if (!logoutItems2.isEmpty() && logoutItems2.get(0).isDisplayed()) {
            logoutItems2.get(0).click();
            return;
        }
    }





    /**
     * Waits until the logout completes successfully by checking for indicators
     * of a logged-out state. On bstackdemo.com, after logout the signin link
     * reappears and the user indicator disappears.
     */
    public void waitForSuccessfulLogout() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(signInLink));
    }

    /**
     * Checks whether the user is currently logged out by verifying the signin
     * link is visible and the user is on the signin page or main page without
     * user context.
     *
     * @return true if the user is logged out, false otherwise
     */
    public boolean isLoggedOut() {
        try {
            // After logout, the signin link should be visible
            return driver.findElements(signInLink).stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Additional Helper Methods for TC_041
    // =========================

    /**
     * Retrieves the displayed username of the currently logged-in user.
     * On bstackdemo.com, after login a username indicator appears in the navigation.
     *
     * @return the displayed username text, or empty string if not found
     */
    public String getLoggedInUsername() {
        try {
            // Wait for the username element to be visible after login
            WebElement usernameElement = new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector(".username, .user-name, [class*='user'], .nav-item")));
            return usernameElement.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Checks whether the login modal is closed.
     * After successful login on bstackdemo.com, the signin form should no longer be visible.
     *
     * @return true if the login modal is closed, false otherwise
     */
    public boolean isLoginModalClosed() {
        try {
            // The signin form should not be visible after successful login
            return new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.invisibilityOfElementLocated(signInForm));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Sign In button is hidden.
     * After successful login, the Sign In button/link should no longer be visible.
     *
     * @return true if the Sign In button is hidden, false otherwise
     */
    public boolean isSignInButtonHidden() {
        try {
            // The signin link should not be visible after login
            return new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.invisibilityOfElementLocated(signInLink));
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Error Message Methods (TC_042)
    // =========================

    /**
     * Retrieves the login error message text from the login form.
     * On bstackdemo.com, when login fails, an error message is displayed
     * near the login button or form.
     *
     * @return the error message text, or empty string if not found
     */
    public String getLoginErrorMessage() {
        try {
            // Wait for the error message to appear
            // The error message typically appears in a div with specific classes
            By errorMessageLocator = By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']");
            WebElement errorElement = new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator));
            return errorElement.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Checks whether a login error message is displayed on the page.
     * This indicates that the login attempt was rejected.
     *
     * @return true if an error message is visible, false otherwise
     */
    public boolean isLoginErrorDisplayed() {
        try {
            By errorMessageLocator = By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']");
            WebElement errorElement = new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator));
            return errorElement.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the login modal/form is still displayed.
     * After a failed login attempt, the modal should remain open.
     *
     * @return true if the login modal is displayed, false otherwise
     */
    public boolean isLoginModalDisplayed() {
        try {
            WebElement formElement = new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.visibilityOfElementLocated(signInForm));
            return formElement.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Sign In button/link is visible.
     * This indicates the user is not logged in.
     *
     * @return true if the Sign In button is visible, false otherwise
     */
    public boolean isSignInButtonVisible() {
        try {
            List<WebElement> signInElements = driver.findElements(signInLink);
            return signInElements.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clicks the "Log In" button to submit the login form without waiting for navigation.
     * This is useful for testing failed login attempts where the page doesn't navigate away.
     * For successful logins, use clickLoginButton() which waits for navigation.
     */
    public void clickLoginButtonWithoutWait() {
        WebElement button = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(loginButton));
        button.click();
    }

    /**
     * Checks whether a JavaScript alert/confirm/prompt dialog is currently present.
     * Intended for security tests (e.g., XSS payloads) to ensure no injected
     * script is executed and no unexpected browser dialogs appear.
     *
     * @return true if a JavaScript alert is present, false otherwise
     */
    public boolean isJavaScriptAlertPresent() {
        try {
            // If an alert is present, switching to it will succeed.
            driver.switchTo().alert();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Session Management Methods (TC_052)
    // =========================

    /**
     * Retrieves the current page URL.
     *
     * @return the current URL as a string
     */
    public String getCurrentPageUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Opens a new browser tab using JavaScript.
     * Uses explicit wait to ensure the new tab is available.
     */
    public void openNewTab() {
        ((JavascriptExecutor) driver).executeScript("window.open('about:blank', '_blank');");
        // Wait for the new tab to be available
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(d -> d.getWindowHandles().size() > 1);
    }

    /**
     * Switches to the newest (most recently opened) browser tab.
     * Uses explicit wait to ensure the tab switch completes.
     */
    public void switchToNewestTab() {
        Set<String> windowHandles = driver.getWindowHandles();
        String newestHandle = windowHandles.stream().reduce((first, second) -> second).orElse("");
        if (!newestHandle.isEmpty()) {
            driver.switchTo().window(newestHandle);
        }
    }

    /**
     * Navigates to the specified URL.
     * Uses explicit wait to ensure the page has started loading.
     *
     * @param url the URL to navigate to
     */
    public void navigateToUrl(String url) {
        driver.get(url);
        // Wait for the page to start loading (document ready state)
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(d -> {
                    JavascriptExecutor js = (JavascriptExecutor) d;
                    return "complete".equals(js.executeScript("return document.readyState"));
                });
    }

    /**
     * Checks whether authentication is required on the current page.
     * This is determined by checking if the Sign In button/link is visible.
     *
     * @return true if authentication is required (Sign In visible), false otherwise
     */
    public boolean isAuthenticationRequired() {
        return isSignInButtonVisible();
    }

    /**
     * Checks whether protected content is visible on the current page.
     * Protected content indicators include: user menu, logout link, order history, etc.
     *
     * @return true if protected content is visible, false otherwise
     */
    public boolean isProtectedContentVisible() {
        try {
            // Check for indicators of authenticated state
            // If user menu or logout link is visible, user is authenticated
            boolean userMenuVisible = driver.findElements(By.cssSelector(".username, .user-name, [class*='user'], .nav-item"))
                    .stream().anyMatch(WebElement::isDisplayed);
            boolean logoutVisible = driver.findElements(logoutLink).stream().anyMatch(WebElement::isDisplayed);
            return userMenuVisible || logoutVisible;
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Session Management Methods (TC_056)
    // =========================

    /**
     * Checks whether the Logout button/link is visible on the page.
     * On bstackdemo.com, after login the logout button or user menu indicator
     * appears in the navigation. The logout button may be directly visible or
     * accessible via a user menu dropdown.
     *
     * @return true if the Logout button or user menu is visible, false otherwise
     */
    public boolean isLogoutButtonVisible() {
        try {
            // Check for the direct logout link first
            List<WebElement> logoutElements = driver.findElements(logoutLink);
            boolean logoutDirectlyVisible = logoutElements.stream().anyMatch(WebElement::isDisplayed);
            if (logoutDirectlyVisible) {
                return true;
            }

            // Fallback: check for user menu indicator (which typically contains logout)
            // On bstackdemo.com, the user menu appears after login and provides access to logout
            By userMenu = By.cssSelector(".username, .user-name, [class*='user'], .nav-item");
            List<WebElement> menuElements = driver.findElements(userMenu);
            boolean userMenuVisible = menuElements.stream().anyMatch(WebElement::isDisplayed);
            if (userMenuVisible) {
                return true;
            }

            // Fallback: check for logout menu item locators
            By logoutMenuItem1 = By.xpath("//*[self::a or self::button][contains(translate(., 'LOGOUT', 'logout'), 'logout')]");
            List<WebElement> logoutItems1 = driver.findElements(logoutMenuItem1);
            if (logoutItems1.stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }

            By logoutMenuItem2 = By.cssSelector("[class*='logout'] a, [class*='logout'] button");
            List<WebElement> logoutItems2 = driver.findElements(logoutMenuItem2);
            return logoutItems2.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the authenticated user session is currently active.
     * A session is considered active when the user is logged in and
     * protected content (user menu or logout link) is visible.
     *
     * @return true if the user session is active, false otherwise
     */
    public boolean isUserSessionActive() {
        try {
            return isLoggedIn() && isProtectedContentVisible();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Waits for the authenticated page to be fully rendered after login or page refresh.
     * This ensures that all authenticated UI elements (user menu, logout button, username)
     * are visible and the page is in a stable state for further interactions.
     * <p>
     * After a page refresh, the React application re-initializes and needs time to:
     * 1. Load the initial HTML shell (document readyState = "complete")
     * 2. Bootstrap the React application
     * 3. Detect the existing session from cookies or localStorage
     * 4. Re-render the authenticated UI elements
     * <p>
     * This method waits for the authenticated state to stabilize by checking that
     * protected content is visible AND the signin button is no longer displayed.
     */
    public void waitForAuthenticatedPage() {
        // Wait for the document to be fully loaded first
        new WebDriverWait(driver, Duration.ofSeconds(15))
                .until(d -> {
                    JavascriptExecutor js = (JavascriptExecutor) d;
                    return "complete".equals(js.executeScript("return document.readyState"));
                });

        // Wait for the authenticated state to stabilize:
        // - User must be logged in (URL is not on /signin page)
        // - Protected content (user menu / logout) must be visible
        // - Sign In button should not be visible
        new WebDriverWait(driver, Duration.ofSeconds(15))
                .until(d -> isLoggedIn() && isProtectedContentVisible() && !isSignInButtonVisible());
    }

    // =========================
    // Session Management Methods (TC_053)
    // =========================

    /**
     * Retrieves the current browser window handle.
     * This is used to store a reference to the current tab so that
     * the WebDriver can switch back to it later.
     *
     * @return the current window handle as a string
     */
    public String getCurrentWindowHandle() {
        return driver.getWindowHandle();
    }

    /**
     * Waits for the application home page to finish loading.
     * Uses explicit wait for document.readyState to be "complete"
     * and for the product listing container to be visible.
     */
    public void waitForApplicationHome() {
        // Wait for the document to be fully loaded
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(d -> {
                    JavascriptExecutor js = (JavascriptExecutor) d;
                    return "complete".equals(js.executeScript("return document.readyState"));
                });
        // Wait for the product listing container to be visible
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".shelf-container")));
    }
}