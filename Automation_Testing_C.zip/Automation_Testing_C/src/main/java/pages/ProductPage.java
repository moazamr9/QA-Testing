package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ProductPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // Product listing locators
    private final By productCard = By.cssSelector(".shelf-item");
    private final By productListing = By.cssSelector(".shelf-container");
    private final By cartBadge = By.cssSelector(".bag__quantity");
    private final By cartContainer = By.cssSelector(".buybox");
    private final By cartButton = By.cssSelector(".bag");
    private final By checkoutButton = By.cssSelector(".checkout-button, button.checkout");
    private final By searchInput = By.cssSelector("input[type='text'], input.search");
    private final By homeLink = By.cssSelector(".logo, a[href='/']");
    private final By homePage = By.cssSelector(".shelf-container");
    private final By emptyCart = By.xpath("//*[contains(text(),'No items') or contains(text(),'empty')]");
    private final By favoritesLink = By.cssSelector(".favorites, a[href*='favorite']");
    private final By favoritesContainer = By.cssSelector(".favorites-container, .favorites-page");
    private final By responsiveLayout = By.cssSelector(".app, .main-wrapper");
    private final By productDetailsContainer = By.cssSelector(".product-details-container, .details-wrapper, .product-page");

    // Vendor filter locators
    private final By clearFilterButton = By.xpath("//*[contains(text(),'Clear') or contains(text(),'Reset')]");

    // Product counter locators (TC_036)
    private final By productCounterLabel = By.cssSelector(".products-found, .result-count, [class*='product-count'], [class*='result'], .shelf-info, .filter-result");

    // No products / empty state locator (TC_029, TC_032)
    private final By noProductsMessage = By.xpath("//*[contains(text(),'No products') or contains(text(),'No results') or contains(text(),'No items') or contains(text(),'no products') or contains(text(),'no results')]");

    // No results message locator (TC_032)
    private final By noResultsMessage = By.xpath("//*[contains(text(),'No results') or contains(text(),'No Products') or contains(text(),'No products found') or contains(text(),'no results') or contains(text(),'No items')]");

    // Sort control locators (TC_030)
    private final By sortDropdown = By.cssSelector("select");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // =========================
    // Sort Dropdown Methods (TC_035)
    // =========================

    /**
     * Checks whether the sort dropdown is visible on the page.
     *
     * @return true if the sort dropdown is displayed
     */
    public boolean isSortDropdownVisible() {
        try {
            WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(sortDropdown));
            return dropdown.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the sort dropdown is enabled and interactable.
     *
     * @return true if the sort dropdown is enabled
     */
    public boolean isSortDropdownEnabled() {
        try {
            WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(sortDropdown));
            return dropdown.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether a specific sort option is currently selected in the dropdown.
     *
     * @param option the visible text of the sorting option to check
     * @return true if the option is currently selected
     */
    public boolean isSortOptionSelected(String option) {
        try {
            WebElement selectElement = wait.until(ExpectedConditions.presenceOfElementLocated(sortDropdown));
            Select select = new Select(selectElement);
            WebElement selectedOption = select.getFirstSelectedOption();
            return selectedOption.getText().trim().equalsIgnoreCase(option);
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Product Listing Methods
    // =========================

    public boolean isProductListingDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(productListing)).isDisplayed();
    }

    public boolean isProductCardDisplayed() {
        return wait.until(d -> {
            List<WebElement> cards = d.findElements(productCard);
            return !cards.isEmpty() && cards.stream().anyMatch(WebElement::isDisplayed);
        });
    }

    public boolean isProductAvailable(String productName) {
        try {
            return getProductCard(productName).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isProductVisible(String productName) {
        try {
            WebElement card = getProductCard(productName);
            return card.isDisplayed() && card.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Product Information Methods
    // =========================

    public String getProductTitle(String productName) {
        WebElement card = getProductCard(productName);
        return card.findElement(By.cssSelector(".shelf-item__title")).getText();
    }

    public String getProductPrice(String productName) {
        WebElement card = getProductCard(productName);
        return card.findElement(By.cssSelector(".shelf-item__price")).getText();
    }

    public String getProductCurrencySymbol(String productName) {
        String price = getProductPrice(productName);
        if (price != null && !price.isEmpty()) {
            return price.substring(0, 1);
        }
        return "";
    }

    public boolean isPriceFormattedWithTwoDecimals(String price) {
        if (price == null || price.isEmpty()) return false;
        // Format: $XXX.XX
        return price.matches("^\\$?\\d+\\.\\d{2}$");
    }

    public boolean isDisplayedPriceExpected(String productName, String expectedPrice) {
        String actualPrice = getProductPrice(productName);
        return expectedPrice.equals(actualPrice);
    }

    public boolean isProductInformationVisible(String productName) {
        try {
            WebElement card = getProductCard(productName);
            return card.findElement(By.cssSelector(".shelf-item__title")).isDisplayed()
                    && card.findElement(By.cssSelector(".shelf-item__price")).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isEmiAmountConsistent(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement emiElement = card.findElement(By.cssSelector(".shelf-item__emi, .shelf-item__installment"));
            String emiText = emiElement.getText().trim();
            // EMI should contain a price that's less than the product price
            return emiText != null && !emiText.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Product Image Methods
    // =========================

    public boolean isProductImageVisible(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement image = card.findElement(By.cssSelector("img"));
            return image.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isProductImageClickable(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement image = card.findElement(By.cssSelector("img"));
            wait.until(ExpectedConditions.elementToBeClickable(image));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void clickProductImage(String productName) {
        WebElement card = getProductCard(productName);
        WebElement image = card.findElement(By.cssSelector("img, a"));
        wait.until(ExpectedConditions.elementToBeClickable(image)).click();
    }

    public boolean isProductDetailsPageDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(productDetailsContainer)).isDisplayed();
        } catch (Exception e) {
            // The details page might be indicated by a URL change or specific content
            return wait.until(d -> d.getCurrentUrl().contains("product") || d.getCurrentUrl().contains("details"));
        }
    }

    // =========================
    // Add to Cart Methods
    // =========================

    public void addProductToCart(String productName) {
        WebElement card = getProductCard(productName);
        // Find the "Add to Cart" button by its text content to avoid accidentally
        // clicking the favorite/heart button. On BrowserStack Demo, the button
        // can be identified by containing "Add to cart" text.
        WebElement addButton = card.findElement(By.xpath(".//*[contains(text(),'Add to cart') or contains(text(),'Add to Cart')]"));
        // Use JavaScript click to avoid ElementClickInterceptedException caused by
        // the fixed header/navbar overlapping the button after scrollIntoView.
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addButton);
    }

    public int getCartBadgeCount() {
        try {
            WebElement badge = driver.findElement(cartBadge);
            String countText = badge.getText().trim();
            return Integer.parseInt(countText);
        } catch (Exception e) {
            return 0;
        }
    }

    public int getCartSubtotal() {
        try {
            WebElement subtotalElement = driver.findElement(By.cssSelector(".subtotal__price, .cart-subtotal"));
            String priceText = subtotalElement.getText().trim().replace("$", "").replace(",", "");
            double price = Double.parseDouble(priceText);
            return (int) (price * 100); // Return in cents
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean isProductDisplayedInCart(String productName) {
        try {
            openCart();
            List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .cart-item__title, .buybox__title"));
            for (WebElement item : cartItems) {
                if (item.getText().trim().contains(productName)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public void openCart() {
        // Cart button may not be clickable due to overlay/transition. Use JS click as fallback.
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(cartButton));
            // Use JS click to avoid strict clickability issues due to overlays/animations.
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(cartButton));
        } catch (Exception e) {
            // last resort: proceed anyway; waits below will handle readiness
        }

        // Cart UI can take longer to render after login/session initialization.
        new WebDriverWait(driver, Duration.ofSeconds(20))
                .until(d -> {
                    // If buybox/cart container exists, consider it opened.
                    if (!d.findElements(cartContainer).isEmpty()) {
                        return d.findElement(cartContainer).isDisplayed();
                    }
                    // Fallback: rely on cart badge count.
                    return getCartBadgeCount() > 0;
                });
    }

    public boolean isCartEmpty() {
        try {
            openCart();
            return driver.findElements(emptyCart).size() > 0
                    || driver.findElements(By.cssSelector(".cart-item")).isEmpty();
        } catch (Exception e) {
            return true;
        }
    }

    public void removeProductFromCart(String productName) {
        openCart();
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        for (WebElement item : cartItems) {
            if (item.getText().contains(productName)) {
                WebElement removeButton = item.findElement(By.cssSelector(".remove-btn, button[class*='remove']"));
                removeButton.click();
                break;
            }
        }
    }

    public void increaseProductQuantity(String productName) {
        openCart();
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        for (WebElement item : cartItems) {
            if (item.getText().contains(productName)) {
                WebElement increaseBtn = item.findElement(By.cssSelector(".increase-btn, button[class*='increase'], button:last-child"));
                increaseBtn.click();
                break;
            }
        }
    }

    public void decreaseProductQuantity(String productName) {
        openCart();
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        for (WebElement item : cartItems) {
            if (item.getText().contains(productName)) {
                WebElement decreaseBtn = item.findElement(By.cssSelector(".decrease-btn, button[class*='decrease'], button:first-child"));
                decreaseBtn.click();
                break;
            }
        }
    }

    public int getProductQuantity(String productName) {
        openCart();
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        for (WebElement item : cartItems) {
            if (item.getText().contains(productName)) {
                WebElement qtyElement = item.findElement(By.cssSelector(".quantity, input[type='number'], .cart-item__quantity"));
                return Integer.parseInt(qtyElement.getAttribute("value").trim());
            }
        }
        return 0;
    }

    public boolean isDecreaseButtonDisabled(String productName) {
        openCart();
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        for (WebElement item : cartItems) {
            if (item.getText().contains(productName)) {
                WebElement decreaseBtn = item.findElement(By.cssSelector(".decrease-btn, button[class*='decrease'], button:first-child"));
                return !decreaseBtn.isEnabled() || "true".equals(decreaseBtn.getAttribute("disabled"));
            }
        }
        return true;
    }

    public void proceedToCheckout() {
        // Navigate directly to the checkout page URL.
        // This avoids issues with the cart panel (ElementClickInterceptedException
        // from the fixed header) and the cart container (.buybox) not being visible.
        driver.get("https://bstackdemo.com/checkout");
        // Wait for the checkout form to be visible by waiting for any form input
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("form input, input")));
    }

    // =========================
    // Search Methods
    // =========================

    public void searchForProduct(String productName) {
        WebElement search = wait.until(ExpectedConditions.elementToBeClickable(searchInput));
        search.clear();
        search.sendKeys(productName);
    }

    /**
     * Clicks the search button to trigger the search operation.
     * Uses a flexible locator to find search buttons with various common selectors.
     */
    public void clickSearchButton() {
        // Try multiple common search button selectors
        By searchButton = By.cssSelector("button[type='submit'], .search-button, .search__button, input[type='submit']");
        try {
            WebElement button = wait.until(ExpectedConditions.elementToBeClickable(searchButton));
            button.click();
        } catch (Exception e) {
            // If no search button exists, the search may be triggered by pressing Enter
            // which is already handled by searchForProduct()
        }
    }

    /**
     * Waits for the search operation to complete by monitoring the visible product count.
     * Uses count-based synchronization compatible with React's DOM reuse behavior.
     *
     * @param initialVisibleCount the number of visible products before search
     */
    public void waitForSearchToComplete(int initialVisibleCount) {
        wait.until(d -> getVisibleProductCount() != initialVisibleCount
                || getVisibleProductCount() == 0);
    }

    /**
     * Checks whether all visible products match the given search keyword.
     * Unlike isOnlyMatchingProductsDisplayed() which checks for exact product name match,
     * this method checks if product titles contain the keyword.
     *
     * @param keyword the search keyword to match against product titles
     * @return true if all visible products contain the keyword in their title
     */
    public boolean areAllVisibleProductsMatchingKeyword(String keyword) {
        List<String> titles = getVisibleProductTitles();
        if (titles.isEmpty()) {
            return false;
        }
        String lowerKeyword = keyword.toLowerCase();
        return titles.stream()
                .allMatch(title -> title.toLowerCase().contains(lowerKeyword));
    }

    /**
     * Checks whether any visible product matches the given search keyword.
     *
     * @param keyword the search keyword to match against product titles
     * @return true if at least one visible product contains the keyword
     */
    public boolean isAnyProductMatchingKeyword(String keyword) {
        List<String> titles = getVisibleProductTitles();
        String lowerKeyword = keyword.toLowerCase();
        return titles.stream()
                .anyMatch(title -> title.toLowerCase().contains(lowerKeyword));
    }

    public boolean isOnlyMatchingProductsDisplayed(String productName) {
        List<WebElement> products = driver.findElements(productCard);
        for (WebElement product : products) {
            if (product.isDisplayed()) {
                String title = product.findElement(By.cssSelector(".shelf-item__title")).getText();
                if (!title.equalsIgnoreCase(productName)) {
                    return false;
                }
            }
        }
        return true;
    }

    // =========================
    // Navigation Methods
    // =========================

    public void navigateToHome() {
        wait.until(ExpectedConditions.elementToBeClickable(homeLink)).click();
    }

    public boolean isHomePageDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(homePage)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isResponsiveLayoutDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(responsiveLayout)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Add to Cart Button Methods
    // =========================

    public boolean isAddToCartButtonVisible(String productName) {
        try {
            WebElement card = getProductCard(productName);
            return card.findElement(By.cssSelector(".shelf-item__buy-btn, button")).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isAddToCartButtonEnabled(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement button = card.findElement(By.cssSelector(".shelf-item__buy-btn, button"));
            return button.isDisplayed() && button.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Favorites Methods
    // =========================

    public boolean isFavoriteIconVisible(String productName) {
        try {
            WebElement card = getProductCard(productName);
            return card.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']")).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isFavoriteIconClickable(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement favIcon = card.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']"));
            wait.until(ExpectedConditions.elementToBeClickable(favIcon));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void clickFavoriteIcon(String productName) {
        WebElement card = getProductCard(productName);
        WebElement favIcon = card.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']"));
        wait.until(ExpectedConditions.elementToBeClickable(favIcon)).click();
    }

    public void waitForFavoriteIconToBecomeActive(String productName) {
        WebElement card = getProductCard(productName);
        // Wait for the favorite icon to get an "active" class or attribute
        wait.until(d -> {
            WebElement favIcon = card.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']"));
            String cls = favIcon.getAttribute("class");
            return cls != null && (cls.contains("active") || cls.contains("selected"));
        });
    }

    public void openFavorites() {
        wait.until(ExpectedConditions.elementToBeClickable(favoritesLink)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(favoritesContainer));
    }

    public boolean isProductDisplayedInFavorites(String productName) {
        try {
            List<WebElement> favItems = driver.findElements(By.cssSelector(".favorites-item, .favorite-product, [class*='favorite']"));
            for (WebElement item : favItems) {
                if (item.getText().contains(productName)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isFavoriteIconActiveOnFavoritesPage(String productName) {
        try {
            List<WebElement> favItems = driver.findElements(By.cssSelector(".favorites-item, .favorite-product, [class*='favorite']"));
            for (WebElement item : favItems) {
                if (item.getText().contains(productName)) {
                    WebElement favIcon = item.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']"));
                    String cls = favIcon.getAttribute("class");
                    return cls != null && (cls.contains("active") || cls.contains("selected"));
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Favorite icon for a product is in the active/selected state
     * on the product listing page.
     *
     * @param productName the name of the product to check
     * @return true if the favorite icon has the "active" or "selected" class
     */
    public boolean isFavoriteIconActive(String productName) {
        try {
            WebElement card = getProductCard(productName);
            WebElement favIcon = card.findElement(By.cssSelector(".favorite-btn, .heart, [class*='favorite'], [class*='heart']"));
            String cls = favIcon.getAttribute("class");
            return cls != null && (cls.contains("active") || cls.contains("selected"));
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // Product Counter Methods (TC_036)
    // =========================

    /**
     * Returns the text of the product counter label displayed on the page.
     * The counter typically shows text like "7 Product(s) found".
     *
     * @return the counter text, or empty string if not found
     */
    public String getProductCounterText() {
        try {
            WebElement counter = wait.until(ExpectedConditions.visibilityOfElementLocated(productCounterLabel));
            return counter.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Extracts the numeric value from the product counter label.
     * Parses text like "7 Product(s) found" and returns the integer 7.
     *
     * @return the numeric count from the counter, or 0 if not parseable
     */
    public int getDisplayedProductCount() {
        String counterText = getProductCounterText();
        if (counterText == null || counterText.isEmpty()) {
            return 0;
        }
        // Extract the first number found in the text
        // Handles formats like "7 Product(s) found", "10 products found", etc.
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\d+");
        java.util.regex.Matcher matcher = pattern.matcher(counterText);
        if (matcher.find()) {
            return Integer.parseInt(matcher.group());
        }
        return 0;
    }

    // =========================
    // Vendor Filter Methods (TC_025, TC_026, TC_027, TC_028)
    // =========================

    /**
     * Returns the count of currently visible product cards.
     * Uses JavaScript to atomically query only elements that are
     * actually visible (not hidden by React's CSS display:none),
     * avoiding StaleElementReferenceException that can occur when
     * iterating over WebElement references during React re-renders.
     */
    public int getVisibleProductCount() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Long count = (Long) js.executeScript(
            "return Array.from(document.querySelectorAll('.shelf-item'))" +
            ".filter(function(el) { return el.offsetParent !== null; }).length;"
        );
        return count.intValue();
    }

    /**
     * Clicks a vendor filter checkbox/label by vendor name.
     * Supported vendor names: Apple, Samsung, Google, OnePlus
     */
    public void clickVendorFilter(String vendorName) {
        By vendorLabel = By.xpath("//label[span[text()='" + vendorName + "']]");
        wait.until(ExpectedConditions.elementToBeClickable(vendorLabel)).click();
    }

    /**
     * Waits for the vendor filtering operation to complete by monitoring
     * the visible product count. This is the preferred synchronization
     * strategy for React-based applications where DOM elements are reused
     * rather than destroyed and recreated.
     *
     * @param initialVisibleCount the number of visible products before filtering
     */
    public void waitForFilterToComplete(int initialVisibleCount) {
        wait.until(d -> getVisibleProductCount() != initialVisibleCount);
    }

    /**
     * Waits for a vendor filter to be fully applied by verifying that ALL
     * expected vendors are represented among the visible products.
     *
     * This method replaces the previous checkbox-based synchronization
     * because the BrowserStack demo's vendor filter uses clickable labels
     * with React state management rather than standard HTML checkboxes.
     * The checkbox locator approach failed because:
     * 1. The DOM may not contain <input type='checkbox'> elements inside the labels
     * 2. Even if present, React may not update the 'checked' property synchronously
     * 3. The isSelected() check is unreliable for custom React checkbox components
     *
     * Instead, this waits for products from ALL expected vendors to appear,
     * which works reliably for both single-vendor and multi-vendor filtering.
     *
     * @param vendorName the vendor whose filter was clicked
     * @param expectedVendors the list of vendors that should be visible after filtering
     */
    public void waitForVendorFilterApplied(String vendorName, List<String> expectedVendors) {
        // Wait for the vendor filtering to settle by verifying that the set of
        // visible vendor names matches EXACTLY the expected vendors.
        //
        // This correctly handles both filter clicks:
        //
        // 1st click (Apple filter on initial load):
        //   Initial visible vendors: {Apple, Samsung, Google, OnePlus}
        //   visibleVendors.size() == expectedVendors.size() ->  4 != 1 -> FALSE, wait
        //   After React renders: {Apple} -> size 1 == 1 -> containsAll([Apple]) -> TRUE
        //
        // 2nd click (Samsung with Apple already selected):
        //   Current visible vendors: {Apple}
        //   visibleVendors.containsAll([Apple, Samsung]) -> FALSE, wait
        //   After React renders: {Apple, Samsung} -> size 2 == 2 -> containsAll -> TRUE
        //
        // The size check prevents the 1st click from returning immediately
        // (Apple is already in the initial set of all vendors).
        // The containsAll check ensures the 2nd click's new vendor has appeared.
        wait.until(d -> {
            Set<String> visibleVendors = getVisibleProductVendors();
            return visibleVendors.size() == expectedVendors.size()
                && visibleVendors.containsAll(expectedVendors);
        });
    }

    /**
     * Returns a list of titles for all currently visible products.
     * Uses JavaScript atomically to avoid StaleElementReferenceException
     * during React re-renders.
     */
    @SuppressWarnings("unchecked")
    public List<String> getVisibleProductTitles() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return (List<String>) js.executeScript(
            "return Array.from(document.querySelectorAll('.shelf-item'))" +
            ".filter(function(el) { return el.offsetParent !== null; })" +
            ".map(function(el) { return el.querySelector('.shelf-item__title').innerText.trim(); });"
        );
    }

    /**
     * Checks whether every visible product belongs to the specified vendor.
     * Determines vendor by checking if the product title contains the vendor keyword.
     *
     * @param vendorName the vendor name (e.g., "Apple", "Samsung")
     * @return true if all visible products belong to the vendor
     */
    public boolean areAllVisibleProductsFromVendor(String vendorName) {
        List<String> titles = getVisibleProductTitles();
        if (titles.isEmpty()) {
            return false;
        }
        // For Apple, products contain "iPhone" in their names
        // For Samsung, products contain "Galaxy" in their names
        // For Google, products contain "Pixel" in their names
        // For OnePlus, products contain "OnePlus" in their names
        String vendorKeyword = getVendorKeyword(vendorName);
        return titles.stream().allMatch(title -> title.toLowerCase().contains(vendorKeyword.toLowerCase()));
    }

    /**
     * Maps a vendor name to the keyword found in the product title.
     */
    private String getVendorKeyword(String vendorName) {
        switch (vendorName.toLowerCase()) {
            case "apple":
                return "iPhone";
            case "samsung":
                return "Galaxy";
            case "google":
                return "Pixel";
            case "oneplus":
                return "OnePlus";
            default:
                return vendorName;
        }
    }

    /**
     * Checks whether every visible product belongs to any of the specified vendors.
     * Reuses getVisibleProductTitles() and getVendorKeyword() to avoid duplication.
     *
     * @param vendorNames the list of allowed vendor names (e.g., "Apple", "Samsung")
     * @return true if all visible products are from the allowed vendors
     */
    public boolean areAllVisibleProductsOnlyFromVendors(List<String> vendorNames) {
        List<String> titles = getVisibleProductTitles();
        if (titles.isEmpty()) {
            return false;
        }
        List<String> keywords = vendorNames.stream()
                .map(this::getVendorKeyword)
                .map(String::toLowerCase)
                .collect(Collectors.toList());
        return titles.stream()
                .allMatch(title -> {
                    String lowerTitle = title.toLowerCase();
                    return keywords.stream().anyMatch(lowerTitle::contains);
                });
    }

    /**
     * Returns the count of visible products that belong to the specified vendor.
     *
     * @param vendorName the vendor name (e.g., "Apple", "Samsung")
     * @return the number of visible products from the vendor
     */
    public long getVisibleProductCountForVendor(String vendorName) {
        List<String> titles = getVisibleProductTitles();
        String vendorKeyword = getVendorKeyword(vendorName);
        return titles.stream()
                .filter(title -> title.toLowerCase().contains(vendorKeyword.toLowerCase()))
                .count();
    }

    /**
     * Returns a set of vendor names inferred from the titles of all visible products.
     * Useful for verification that both expected vendors are present.
     */
    public Set<String> getVisibleProductVendors() {
        List<String> titles = getVisibleProductTitles();
        Set<String> vendors = new HashSet<>();
        for (String title : titles) {
            String vendor = getVendorFromTitle(title);
            if (vendor != null) {
                vendors.add(vendor);
            }
        }
        return vendors;
    }

    /**
     * Maps a product title to its vendor name based on product naming conventions.
     */
    private String getVendorFromTitle(String title) {
        String lower = title.toLowerCase();
        if (lower.contains("iphone")) return "Apple";
        if (lower.contains("galaxy")) return "Samsung";
        if (lower.contains("pixel")) return "Google";
        if (lower.contains("oneplus")) return "OnePlus";
        return null;
    }

    // =========================
    // Clear Filter Methods (TC_028)
    // =========================

    /**
     * Clicks the clear/reset button to remove all applied filters.
     * After clicking, all products should be displayed again.
     */
    public void clickClearFilter() {
        try {
            WebElement clearButton = wait.until(ExpectedConditions.elementToBeClickable(clearFilterButton));
            clearButton.click();
        } catch (Exception e) {
            // Fallback: try to find the clear button using a broader locator
            By fallbackClearButton = By.xpath("//button[contains(text(),'Clear') or contains(text(),'Reset')]");
            WebElement clearButton = wait.until(ExpectedConditions.elementToBeClickable(fallbackClearButton));
            clearButton.click();
        }
    }

    /**
     * Waits for the filters to be cleared by monitoring the visible vendors.
     * After clearing, products from multiple vendors should appear until
     * at least two different vendors are visible.
     */
    public void waitForClearFilterToComplete() {
        wait.until(d -> {
            Set<String> visibleVendors = getVisibleProductVendors();
            return visibleVendors.size() >= 2;
        });
    }

    /**
     * Checks whether the clear/reset filter button is displayed.
     * This can be used to verify that a "Clear" button appears when filters are applied.
     *
     * @return true if the clear filter button is visible
     */
    public boolean isClearFilterButtonDisplayed() {
        try {
            WebElement clearButton = driver.findElement(clearFilterButton);
            return clearButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether at least one product from each of the major vendors is visible.
     * This indicates filters have been cleared and all products are shown.
     *
     * @return true if products from Apple, Samsung, Google, and OnePlus are all present
     */
    public boolean areProductsFromAllVendorsDisplayed() {
        Set<String> visibleVendors = getVisibleProductVendors();
        // All 4 major vendors should be present when filters are cleared
        return visibleVendors.contains("Apple")
            && visibleVendors.contains("Samsung")
            && visibleVendors.contains("Google")
            && visibleVendors.contains("OnePlus");
    }

    // =========================
    // Page Refresh & Reload Methods (TC_027)
    // =========================

    /**
     * Refreshes the current browser page using Selenium's navigate().refresh().
     * This triggers a full page reload from the server.
     */
    public void refreshPage() {
        driver.navigate().refresh();
    }

    /**
     * Checks whether a vendor filter checkbox/label is currently selected.
     * Detects selection by examining the CSS class of the filter label element
     * for the "checked" class, which is how the BrowserStack demo's React
     * checkbox components indicate their selected state.
     *
     * @param vendorName the vendor name (e.g., "Apple", "Samsung")
     * @return true if the vendor filter label has the "checked" class
     */
    public boolean isVendorFilterSelected(String vendorName) {
        try {
            By vendorLabel = By.xpath("//label[span[text()='" + vendorName + "']]");
            WebElement label = wait.until(ExpectedConditions.presenceOfElementLocated(vendorLabel));
            String classAttribute = label.getAttribute("class");
            return classAttribute != null && classAttribute.contains("checked");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Waits for the page to fully reload after a refresh or navigation action.
     * Synchronizes on two conditions:
     * 1. document.readyState equals "complete" (all resources loaded)
     * 2. The product listing container is visible (React rendering finished)
     *
     * This ensures that all assertions following a refresh operate on
     * a fully rendered page rather than an intermediate loading state.
     */
    public void waitForPageReload() {
        // Wait for the document to be fully loaded
        wait.until(d -> {
            JavascriptExecutor js = (JavascriptExecutor) d;
            return "complete".equals(js.executeScript("return document.readyState"));
        });
        // Wait for the product listing to be visible after React re-renders
        waitForProductListing();
    }

    /**
     * Waits for the product listing container to be visible.
     * Provides a synchronization point after navigation or page changes
     * where product visibility must be confirmed before proceeding.
     */
    public void waitForProductListing() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(productListing));
    }

    // =========================
    // Invalid Vendor Filter Methods (TC_029)
    // =========================

    /**
     * Checks whether a vendor filter label exists and is displayed in the DOM.
     * Used to verify that a specific vendor is present in the available filter options.
     *
     * @param vendorName the vendor name to check (e.g., "Apple", "XYZ")
     * @return true if the vendor filter label is present and displayed
     */
    public boolean isVendorPresent(String vendorName) {
        try {
            By vendorLabel = By.xpath("//label[span[text()='" + vendorName + "']]");
            WebElement element = driver.findElement(vendorLabel);
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Attempts to select a vendor filter gracefully without throwing an exception
     * if the vendor does not exist. This is used for negative testing with
     * invalid/non-existent vendor names.
     *
     * @param vendorName the vendor name to attempt to select
     * @return true if the vendor was found and clicked successfully, false otherwise
     */
    public boolean attemptToSelectVendor(String vendorName) {
        try {
            By vendorLabel = By.xpath("//label[span[text()='" + vendorName + "']]");
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(vendorLabel));
            element.click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether a "No Products Found" or equivalent empty-state message
     * is displayed on the page. This message may appear when a filter yields
     * no matching results.
     *
     * @return true if an empty-state message is visible
     */
    public boolean isNoProductsMessageDisplayed() {
        try {
            List<WebElement> messages = driver.findElements(noProductsMessage);
            return messages.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the product grid is empty (no visible products).
     * Uses the same JavaScript-based visibility check as getVisibleProductCount().
     *
     * @return true if no products are currently visible
     */
    public boolean isProductGridEmpty() {
        return getVisibleProductCount() == 0;
    }

    // =========================
    // Search Input Methods (TC_032)
    // =========================

    /**
     * Checks whether the search input field is visible and ready for interaction.
     *
     * @return true if the search input is displayed and enabled
     */
    public boolean isSearchInputVisible() {
        try {
            WebElement search = wait.until(ExpectedConditions.presenceOfElementLocated(searchInput));
            return search.isDisplayed() && search.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    // =========================
    // No Results Message Methods (TC_032)
    // =========================

    /**
     * Checks whether a "No Results" or equivalent empty-state message
     * is displayed on the page after a search operation.
     * This is specifically for search-related empty states.
     *
     * @return true if a no-results message is visible
     */
    public boolean isNoResultsMessageDisplayed() {
        try {
            List<WebElement> messages = driver.findElements(noResultsMessage);
            return messages.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the text of the "No Results" message if displayed.
     *
     * @return the message text, or empty string if not found
     */
    public String getNoResultsMessage() {
        try {
            List<WebElement> messages = driver.findElements(noResultsMessage);
            for (WebElement message : messages) {
                if (message.isDisplayed()) {
                    return message.getText().trim();
                }
            }
        } catch (Exception e) {
            // Ignore exceptions
        }
        return "";
    }

    // =========================
    // React Render Synchronization (TC_032)
    // =========================

    /**
     * Waits for React to finish rendering the updated product list.
     * Uses document.readyState and product count stabilization to ensure React
     * has completed its rendering cycle.
     */
    public void waitForReactRenderComplete() {
        // Wait for document to be ready
        wait.until(d -> {
            JavascriptExecutor js = (JavascriptExecutor) d;
            return "complete".equals(js.executeScript("return document.readyState"));
        });
        // Wait for product count to stabilize (no changes for a short period)
        // This ensures React has finished re-rendering the product list
        wait.until(d -> {
            int count1 = getVisibleProductCount();
            // Use a polling approach to check for stabilization
            // The wait.until will poll until the condition is true
            int count2 = getVisibleProductCount();
            return count1 == count2;
        });
    }

    // =========================
    // Sorting Methods (TC_030)
    // =========================

    /**
     * Selects a sorting option from the product sort dropdown.
     * Uses Selenium's Select class to interact with the native <select> element.
     *
     * @param option the visible text of the sorting option (e.g., "Lowest Price")
     */
    public void selectSortingOption(String option) {
        WebElement selectElement = wait.until(ExpectedConditions.elementToBeClickable(sortDropdown));
        Select select = new Select(selectElement);
        select.selectByVisibleText(option);
    }

    /**
     * Waits for the sorting operation to complete by polling the visible
     * product prices until they are in ascending order.
     *
     * This is the only reliable synchronization strategy for React-based
     * sort controls because:
     * 1. document.readyState is already "complete" after initial page load.
     * 2. The product count does not change during sorting.
     * 3. The product listing container remains visible throughout the sort.
     * 4. Polling the actual sorted condition directly confirms that React
     *    has finished re-rendering the sorted product list.
     */
    public void waitForSortingToComplete() {
        wait.until(d -> arePricesSortedAscending());
    }

    /**
     * Returns the numeric prices of all currently visible products.
     * Parses price strings (e.g., "$19.99") into Double values.
     * Uses JavaScript atomically to avoid StaleElementReferenceException
     * during React re-renders.
     *
     * Handles multi-line price text (e.g., "$799.00\nor 9 x 88.78") by
     * extracting only the first line which contains the actual price.
     *
     * @return a list of price values in display order
     */
    @SuppressWarnings("unchecked")
    public List<Double> getVisibleProductPrices() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        List<String> priceStrings = (List<String>) js.executeScript(
            "return Array.from(document.querySelectorAll('.shelf-item'))" +
            ".filter(function(el) { return el.offsetParent !== null; })" +
            ".map(function(el) { return el.querySelector('.shelf-item__price').innerText.trim(); });"
        );
        return priceStrings.stream()
                .map(p -> p.split("\\n")[0])  // Extract only the first line (the price)
                .map(p -> p.replace("$", "").replace(",", "").trim())
                .map(Double::parseDouble)
                .collect(Collectors.toList());
    }

    /**
     * Checks whether the visible product prices are sorted in ascending order.
     *
     * @return true if each price is &le; the next price
     */
    public boolean arePricesSortedAscending() {
        List<Double> prices = getVisibleProductPrices();
        for (int i = 0; i < prices.size() - 1; i++) {
            if (prices.get(i) > prices.get(i + 1)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks whether the visible product prices are sorted in descending order.
     *
     * @return true if each price is &ge; the next price
     */
    public boolean arePricesSortedDescending() {
        List<Double> prices = getVisibleProductPrices();
        for (int i = 0; i < prices.size() - 1; i++) {
            if (prices.get(i) < prices.get(i + 1)) {
                return false;
            }
        }
        return true;
    }

    // =========================
    // Checkout & Order Placement Methods (TC_038)
    // =========================

    // Checkout page locators
    // Flexible XPath locators to match BrowserStack Demo checkout form input fields
    private final By checkoutFirstNameInput = By.xpath("//input[contains(@placeholder,'First') or contains(@name,'firstName') or contains(@id,'first')]");
    private final By checkoutLastNameInput = By.xpath("//input[contains(@placeholder,'Last') or contains(@name,'lastName') or contains(@id,'last')]");
    private final By checkoutAddressInput = By.xpath("//input[contains(@placeholder,'Address') or contains(@name,'address') or contains(@id,'address')]");
    private final By checkoutStateProvinceInput = By.xpath("//input[contains(@placeholder,'State') or contains(@name,'state') or contains(@id,'state') or contains(@placeholder,'Province')]");
    private final By checkoutPostalCodeInput = By.xpath("//input[contains(@placeholder,'Postal') or contains(@placeholder,'Zip') or contains(@name,'postal') or contains(@name,'zip') or contains(@id,'postal') or contains(@id,'zip')]");
    private final By checkoutSubmitButton = By.xpath("//button[contains(text(),'Submit') or contains(text(),'Place Order') or contains(text(),'Order') or @id='checkout-btn' or contains(@class,'checkout')]");
    // Order confirmation page locators - updated to match actual bstackdemo.com/confirmation page
    private final By orderConfirmationContainer = By.cssSelector(".confirmation-page, .order-confirmation, #confirmation-page, [class*='confirmation'], [class*='thank']");
    private final By orderConfirmationMessage = By.xpath("//*[contains(text(),'Thank you') or contains(text(),'Order placed') or contains(text(),'order has been placed') or contains(text(),'Confirmation') or contains(text(),'successfully placed') or contains(text(),'Your order has been')]");
    private final By continueShoppingButton = By.xpath("//button[contains(.,'Continue') or contains(.,'continue') or contains(text(),'Continue Shopping') or contains(text(),'Continue')]");

    /**
     * Fills in the checkout form with the given details and places the order.
     * This simulates a complete purchase flow on the BrowserStack Demo checkout page.
     *
     * The method scopes to the checkout form and fills all visible text input
     * fields in DOM order (First Name, Last Name, Address, State/Province,
     * Postal Code). This is robust against varying attribute names and works
     * with React-controlled input components.
     *
     * @param firstName    the first name for the shipping address
     * @param lastName     the last name for the shipping address
     * @param address      the street address for shipping
     * @param stateProvince the state or province for shipping
     * @param postalCode   the postal code for shipping
     */
    public void placeOrder(String firstName, String lastName, String address,
                           String stateProvince, String postalCode) {
        // Wait for the checkout page to fully load by waiting for any form input
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("form input, input")));

        // Scope to the checkout form to avoid the header search box
        WebElement form = wait.until(d -> {
            List<WebElement> forms = d.findElements(By.cssSelector("form"));
            for (WebElement f : forms) {
                if (f.isDisplayed()) {
                    return f;
                }
            }
            // Fallback: use body if no visible form is found
            return d.findElement(By.tagName("body"));
        });

        // Get all visible text inputs within the checkout form
        List<WebElement> formInputs = form.findElements(By.cssSelector("input"))
                .stream()
                .filter(WebElement::isDisplayed)
                .filter(e -> {
                    String type = e.getAttribute("type");
                    return type == null || type.equals("text") || type.equals("");
                })
                .collect(Collectors.toList());

        // Fill fields in order: First Name, Last Name, Address, State/Province, Postal Code
        String[] values = {firstName, lastName, address, stateProvince, postalCode};
        int count = Math.min(values.length, formInputs.size());
        for (int i = 0; i < count; i++) {
            WebElement field = formInputs.get(i);
            // Scroll into view and click to focus the React-controlled input
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", field);
            field.click();
            field.clear();
            field.sendKeys(values[i]);
        }

        // Click the "Submit" / "Place Order" button via JavaScript to avoid header overlap
        WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(checkoutSubmitButton));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitButton);
    }

    /**
     * Waits for the order confirmation page to appear after placing an order.
     * Checks for either the confirmation container/message OR a URL change
     * to an order/confirmation page.
     */
    public void waitForOrderConfirmation() {
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(orderConfirmationContainer),
                ExpectedConditions.visibilityOfElementLocated(orderConfirmationMessage),
                // Fallback: URL changed to an order/confirmation page
                ExpectedConditions.urlContains("order"),
                ExpectedConditions.urlContains("confirm"),
                ExpectedConditions.urlContains("thank")
        ));
    }

    /**
     * Checks whether the order confirmation page / thank-you message is displayed.
     *
     * @return true if the order confirmation is visible
     */
    public boolean isOrderConfirmationDisplayed() {
        try {
            return driver.findElements(orderConfirmationContainer).stream().anyMatch(WebElement::isDisplayed)
                    || driver.findElements(orderConfirmationMessage).stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Extracts the order number from the order confirmation page.
     * The order number is displayed in text like "Your order number is 17."
     *
     * @return the order number as a string (e.g., "17"), or empty string if not found
     */
    public String getOrderNumber() {
        try {
            String bodyText = driver.findElement(By.tagName("body")).getText();
            // Look for pattern "Your order number is X." or "Order #X"
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("Your order number is (\\d+)");
            java.util.regex.Matcher matcher = pattern.matcher(bodyText);
            if (matcher.find()) {
                return matcher.group(1);
            }
            // Try alternative pattern
            pattern = java.util.regex.Pattern.compile("Order #(\\d+)");
            matcher = pattern.matcher(bodyText);
            if (matcher.find()) {
                return matcher.group(1);
            }
        } catch (Exception e) {
            // Return empty string
        }
        return "";
    }

    /**
     * Clicks the "Continue Shopping" button to return to the product listing
     * after placing an order.
     */
    public void clickContinueShopping() {
        WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(continueShoppingButton));
        continueBtn.click();
        waitForProductListing();
    }

    /**
     * Performs a complete checkout flow: adds the given product to the cart,
     * proceeds to checkout, fills the shipping details, and places the order.
     *
     * @param productName   the name of the product to purchase
     * @param firstName     the first name for shipping
     * @param lastName      the last name for shipping
     * @param address       the street address for shipping
     * @param stateProvince the state or province for shipping
     * @param postalCode    the postal code for shipping
     */
    public void purchaseProduct(String productName, String firstName, String lastName,
                                String address, String stateProvince, String postalCode) {
        addProductToCart(productName);
        openCart();
        proceedToCheckout();
        placeOrder(firstName, lastName, address, stateProvince, postalCode);
        waitForOrderConfirmation();
    }

    // =========================
    // Offers Methods (TC_040)
    // =========================

    // Offers page locators
    private final By offersLink = By.cssSelector("a[href*='offer'], a[href*='offers']");
    private final By offersButton = By.cssSelector("button[id*='offer'], button[id*='offers']");
    // XPath fallback for text-based link detection
    private final By offersLinkByText = By.xpath("//a[contains(translate(., 'OFFERS', 'offers'), 'offers') or contains(translate(., 'OFFERS', 'offers'), 'Offers')]");
    // Offers page container - main element with fit class
    private final By offersPage = By.cssSelector("main.fit, .offers-page, .offers-container");
    private final By offerList = By.cssSelector(".offers-listing, .offers-container, .offers-list");
    private final By offerItem = By.cssSelector(".offer, .offer-card, .offer-item, [class*='offer']");
    private final By loadingIndicator = By.cssSelector(".loading, .spinner, [class*='loading'], [class*='spinner']");
    // No offers message locator - matches "Sorry we do not have any promotional offers in your city."
    private final By noOffersMessage = By.xpath("//*[contains(text(),'Sorry') and contains(text(),'offers') and contains(text(),'city')]");
    // Alternative locator for the no offers message
    private final By noOffersMessageAlt = By.xpath("//*[contains(text(),'Sorry we do not have any promotional offers')]");
    // Geo-location error message locator - matches the error div (Tailwind CSS classes)
    private final By geoLocationError = By.cssSelector("div[class*='text-red-50'], .pt-6");
    // Offer title locator
    private final By offerTitle = By.cssSelector(".offer-title");
    // Generic error message locator for offers page
    private final By offersErrorMessage = By.xpath("//*[contains(text(),'Sorry') or contains(text(),'Geolocation') or contains(text(),'enable Geolocation') or contains(text(),'not available')]");

    /**
     * Checks whether the Offers navigation link exists in the DOM.
     *
     * @return true if the Offers link is present in the DOM
     */
    public boolean isOffersLinkPresent() {
        try {
            // Check CSS selectors first
            List<WebElement> links = driver.findElements(offersLink);
            List<WebElement> buttons = driver.findElements(offersButton);
            if (!links.isEmpty() || !buttons.isEmpty()) {
                return true;
            }
            // Check XPath fallback for text-based link detection
            List<WebElement> textLinks = driver.findElements(offersLinkByText);
            return !textLinks.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Offers navigation link is visible.
     *
     * @return true if the Offers link is displayed
     */
    public boolean isOffersLinkVisible() {
        try {
            // Try link first
            List<WebElement> links = driver.findElements(offersLink);
            for (WebElement link : links) {
                if (link.isDisplayed()) {
                    return true;
                }
            }
            // Try button if no visible link found
            List<WebElement> buttons = driver.findElements(offersButton);
            for (WebElement button : buttons) {
                if (button.isDisplayed()) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether the Offers navigation link is enabled.
     *
     * @return true if the Offers link is enabled and clickable
     */
    public boolean isOffersLinkEnabled() {
        try {
            // Try link first
            List<WebElement> links = driver.findElements(offersLink);
            for (WebElement link : links) {
                if (link.isDisplayed() && link.isEnabled()) {
                    return true;
                }
            }
            // Try button if no enabled link found
            List<WebElement> buttons = driver.findElements(offersButton);
            for (WebElement button : buttons) {
                if (button.isDisplayed() && button.isEnabled()) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clicks the Offers navigation link.
     * Uses explicit wait to ensure the element is clickable.
     * Falls back to direct URL navigation if the link is not found.
     */
    public void clickOffers() {
        // Try link first
        List<WebElement> links = driver.findElements(offersLink);
        for (WebElement link : links) {
            if (link.isDisplayed() && link.isEnabled()) {
                wait.until(ExpectedConditions.elementToBeClickable(offersLink)).click();
                return;
            }
        }
        // Try button if no clickable link found
        List<WebElement> buttons = driver.findElements(offersButton);
        for (WebElement button : buttons) {
            if (button.isDisplayed() && button.isEnabled()) {
                wait.until(ExpectedConditions.elementToBeClickable(offersButton)).click();
                return;
            }
        }
        // Fallback: Try XPath for text-based link detection
        try {
            List<WebElement> textLinks = driver.findElements(offersLinkByText);
            for (WebElement link : textLinks) {
                if (link.isDisplayed() && link.isEnabled()) {
                    link.click();
                    return;
                }
            }
        } catch (Exception e) {
            // Ignore and try direct URL navigation
        }
        // Final fallback: Navigate directly to the offers page URL
        driver.get("https://bstackdemo.com/offers");
    }

    /**
     * Waits for the Offers page to load completely.
     * Uses explicit wait for the page container to be visible.
     */
    public void waitForOffersPage() {
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(offersPage),
                ExpectedConditions.visibilityOfElementLocated(offerList),
                ExpectedConditions.urlContains("offer")
        ));
    }

    /**
     * Checks whether the Offers page is displayed.
     *
     * @return true if the Offers page is visible
     */
    public boolean isOffersPageDisplayed() {
        try {
            // Check for offers page container
            if (driver.findElements(offersPage).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for offer list
            if (driver.findElements(offerList).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for offer items
            if (driver.findElements(offerItem).stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check URL for offers page
            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("offer")) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the count of displayed offers.
     *
     * @return the number of visible offer items
     */
    public int getOfferCount() {
        try {
            List<WebElement> items = driver.findElements(offerItem);
            if (!items.isEmpty()) {
                return (int) items.stream().filter(WebElement::isDisplayed).count();
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Checks whether at least one offer is displayed.
     *
     * @return true if there is at least one offer displayed
     */
    public boolean hasOffers() {
        return getOfferCount() > 0;
    }

    /**
     * Checks whether all displayed offers have visible information.
     * Each offer should have at least a title, description, or coupon text.
     *
     * @return true if all offers have visible information
     */
    public boolean areOffersVisible() {
        try {
            List<WebElement> items = driver.findElements(offerItem);
            if (items.isEmpty()) {
                return false;
            }
            for (WebElement item : items) {
                if (item.isDisplayed()) {
                    // Check if the offer has any text content (title, description, coupon)
                    String text = item.getText().trim();
                    if (text.isEmpty()) {
                        return false;
                    }
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether every displayed offer contains visible information.
     * Verifies that each offer has meaningful content (title, description, or promotional text).
     *
     * @return true if every offer has visible information
     */
    public boolean isOfferInformationDisplayed() {
        try {
            List<WebElement> items = driver.findElements(offerItem);
            if (items.isEmpty()) {
                return false;
            }
            for (WebElement item : items) {
                if (item.isDisplayed()) {
                    String text = item.getText().trim();
                    // Each offer should have some meaningful text content
                    if (text.isEmpty() || text.length() < 3) {
                        return false;
                    }
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether a "No offers" or equivalent empty-state message is displayed.
     * This message appears when there are no offers available for the user's region.
     *
     * @return true if a no-offers message is visible
     */
    public boolean isNoOffersMessageDisplayed() {
        try {
            // Check primary locator
            List<WebElement> messages = driver.findElements(noOffersMessage);
            if (messages.stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check alternative locator
            List<WebElement> altMessages = driver.findElements(noOffersMessageAlt);
            if (altMessages.stream().anyMatch(WebElement::isDisplayed)) {
                return true;
            }
            // Check for geo-location error message
            List<WebElement> geoErrors = driver.findElements(geoLocationError);
            return geoErrors.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether a geo-location error message is displayed.
     * This message appears when geolocation is not available or offers are not available for the region.
     *
     * @return true if a geo-location error message is visible
     */
    public boolean isGeoLocationErrorDisplayed() {
        try {
            List<WebElement> errors = driver.findElements(geoLocationError);
            return errors.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether any loading indicators are still present on the page.
     *
     * @return true if no loading indicators are visible
     */
    public boolean isNotLoading() {
        try {
            List<WebElement> indicators = driver.findElements(loadingIndicator);
            return indicators.stream().noneMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return true;
        }
    }

    // =========================
    // Cart Item Names Method (TC_057)
    // =========================

    /**
     * Retrieves the names of all products currently displayed in the shopping cart.
     * Assumes the cart drawer is already open. Extracts the title text from each cart item.
     * Call openCart() before calling this method if the cart is not already open.
     *
     * @return a list of product names (titles) currently in the cart, or an empty list if the cart is empty
     */
    public List<String> getCartItemNames() {
        // Wait for cart items to be fully loaded
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(cartContainer));
        } catch (Exception e) {
            // If cart container is not visible, cart might be empty
            return List.of();
        }
        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart-item, .buybox-item"));
        return cartItems.stream()
                .map(item -> {
                    try {
                        // Try to get the title from the cart item
                        WebElement titleElement = item.findElement(By.cssSelector(".cart-item__title, .buybox__title, .shelf-item__title, [class*='title']"));
                        return titleElement.getText().trim();
                    } catch (Exception e) {
                        return "";
                    }
                })
                .filter(name -> !name.isEmpty())
                .collect(Collectors.toList());
    }

    // =========================
    // Helper Methods
    // =========================

    private WebElement getProductCard(String productName) {
        return wait.until(d -> {
            List<WebElement> cards = d.findElements(productCard);
            for (WebElement card : cards) {
                if (card.findElement(By.cssSelector(".shelf-item__title")).getText().trim().equals(productName)) {
                    return card;
                }
            }
            throw new org.openqa.selenium.NoSuchElementException("Product not found: " + productName);
        });
    }
}