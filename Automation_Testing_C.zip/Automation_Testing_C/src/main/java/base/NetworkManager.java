package base;

import java.util.Map;
import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chromium.HasCdp;

public final class NetworkManager {

    private static final String EMULATE_NETWORK_CONDITIONS = "Network.emulateNetworkConditions";
    private static final int NO_LATENCY = 0;
    private static final int NO_THROTTLING = -1;
    private static final int OFFLINE_THROUGHPUT = 0;

    private NetworkManager() {
    }

    public static void goOffline(WebDriver driver) {
        executeNetworkCommand(driver, Map.of(
                "offline", true,
                "latency", NO_LATENCY,
                "downloadThroughput", OFFLINE_THROUGHPUT,
                "uploadThroughput", OFFLINE_THROUGHPUT,
                "connectionType", "none"));
    }

    public static void goOnline(WebDriver driver) {
        executeNetworkCommand(driver, Map.of(
                "offline", false,
                "latency", NO_LATENCY,
                "downloadThroughput", NO_THROTTLING,
                "uploadThroughput", NO_THROTTLING,
                "connectionType", "wifi"));
    }

    private static void executeNetworkCommand(WebDriver driver, Map<String, Object> parameters) {
        Objects.requireNonNull(driver, "driver must not be null");

        if (!(driver instanceof HasCdp cdpDriver)) {
            throw new IllegalArgumentException(
                    "Network control requires a Chromium-based WebDriver session with CDP support.");
        }

        cdpDriver.executeCdpCommand(EMULATE_NETWORK_CONDITIONS, parameters);
    }
}
