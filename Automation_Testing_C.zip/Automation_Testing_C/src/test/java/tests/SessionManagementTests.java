package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.OrderHistoryPage;
import pages.ProductPage;

import java.time.Duration;
import java.util.List;

/**
 * Test class for Session Management functionality.
 * Contains TC_052, TC_053, TC_056, and TC_057.
 * <p>
 * TC_052: Verifies that a user cannot access protected application functionality
 *         by directly navigating to a previously accessible URL after logging out.
 * <p>
 * TC_053: Verifies that an authenticated user session is maintained across
 *         multiple browser tabs opened within the same browser instance.
 * <p>
 * TC_056: Verifies that the authenticated user session is maintained after
 *         refreshing the browser page.
 * <p>
 * TC_057: Verifies that shopping cart contents are isolated between different
 *         user accounts and are not shared across authenticated sessions.
 */
public class SessionManagementTests extends BaseTest {

    // Test data constants
    private static final String USERNAME = "demouser";
    private static final String PASSWORD = "testingisfun99";
    private static final String USERNAME_B = "fav_user";
    private static final String PASSWORD_B = "testingisfun99";
    private static final String BASE_URL = "https://bstackdemo.com/";
    private static final String TEST_PRODUCT = "iPhone 12";

    // =========================
    // TC_052 - Access System Using Direct URL Without Login
    // =========================

    @Test
    public void tc052_accessSystemUsingDirectUrlWithoutLogin() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the user is initially logged out
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Perform Login (Reuse existing functionality)
        // =====================================================

        // Step 4: Log in using the existing reusable login functionality
        System.setProperty("demo.username", USERNAME);
        System.setProperty("demo.password", PASSWORD);
        loginPage.loginAsExistingUser();

        // Step 5: Wait until authentication completes successfully
        loginPage.waitForSuccessfulLogin();

        // Step 6: Verify that the user is authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after successful login");

        // =====================================================
        // PHASE 3: Navigate to Protected Page
        // =====================================================

        // Step 7: Navigate to a page that requires authentication (Orders page)
        orderHistoryPage.clickOrders();

        // Step 8: Wait for the Order History page to load
        orderHistoryPage.waitForOrdersPage();

        // Step 9: Verify that the page has loaded successfully
        Assert.assertTrue(orderHistoryPage.isOrdersPageDisplayed(),
                "Order History page should be displayed after clicking Orders link");

        // Step 10: Capture the current URL
        String protectedPageUrl = loginPage.getCurrentPageUrl();
        Assert.assertFalse(protectedPageUrl.isEmpty(),
                "Protected page URL should be captured successfully");
        Assert.assertTrue(protectedPageUrl.contains("order") || protectedPageUrl.contains("orders"),
                "Captured URL should be for the Orders page. Actual URL: " + protectedPageUrl);

        // =====================================================
        // PHASE 4: Perform Logout (Reuse existing functionality)
        // =====================================================

        // Step 11: Navigate back to home page to ensure logout is accessible
        productPage.navigateToHome();

        // Step 12: Log out using the existing reusable logout functionality
        loginPage.logout();

        // Step 13: Wait until logout completes
        loginPage.waitForSuccessfulLogout();

        // Step 14: Verify that the session has been terminated
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Sign In button should be visible after logout (session terminated)");

        // =====================================================
        // PHASE 5: Access Protected URL in New Tab
        // =====================================================

        // Step 15: Open a new browser tab
        loginPage.openNewTab();

        // Step 16: Switch to the new tab
        loginPage.switchToNewestTab();

        // Step 17: Navigate directly to the previously captured URL
        loginPage.navigateToUrl(protectedPageUrl);

        // Step 18: Wait for navigation to complete
        // The page should either redirect to login or show authentication required
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(d -> {
                    String currentUrl = d.getCurrentUrl();
                    // Check if we're on signin page or if signin button is visible
                    return currentUrl.contains("/signin") ||
                           currentUrl.contains("/login") ||
                           loginPage.isSignInButtonVisible() ||
                           !loginPage.isProtectedContentVisible();
                });

        // =====================================================
        // PHASE 6: Verify Authentication Required
        // =====================================================

        // Step 19: Verify the application's response
        // The application should require authentication - either:
        // - Redirect to login page, OR
        // - Show Sign In interface, OR
        // - Show authorization requirement, OR
        // - Prevent protected content from being accessed

        // Check that we are on the signin page (URL contains /signin)
        String currentUrl = driver.getCurrentUrl();
        boolean onSigninPage = currentUrl.contains("/signin") || currentUrl.contains("/login");

        // Check that Sign In button is visible (authentication required)
        boolean signInVisible = loginPage.isSignInButtonVisible();

        // Check that protected content is NOT visible
        boolean protectedContentNotVisible = !loginPage.isProtectedContentVisible();

        // The test passes if any of these secure behaviors are detected:
        // 1. Redirected to signin page, OR
        // 2. Sign In button is visible, OR
        // 3. Protected content is not accessible
        Assert.assertTrue(onSigninPage || signInVisible || protectedContentNotVisible,
                "Application should require authentication after logout. " +
                "Expected one of: redirect to /signin, Sign In button visible, or protected content not accessible. " +
                "Current URL: " + currentUrl);

        // Step 20: Verify that the user remains unauthenticated
        // If we're on the signin page or Sign In is visible, user is not authenticated
        // If protected content is not visible, user is also not authenticated
        boolean userIsUnauthenticated = onSigninPage || signInVisible || protectedContentNotVisible;
        Assert.assertTrue(userIsUnauthenticated,
                "User should remain unauthenticated when accessing protected URL after logout. " +
                "Current URL: " + currentUrl);
    }

    // =========================
    // TC_056 - Session Persistence After Page Refresh
    // =========================

    @Test
    public void tc056_sessionPersistenceAfterPageRefresh() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // =====================================================
        // PHASE 2: Perform Login (Reuse existing functionality)
        // =====================================================

        // Step 3: Log in using the existing reusable login functionality
        System.setProperty("demo.username", USERNAME);
        System.setProperty("demo.password", PASSWORD);
        loginPage.loginAsExistingUser();

        // Step 4: Wait until authentication completes successfully
        loginPage.waitForSuccessfulLogin();

        // Step 5: Verify that the user is authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after successful login");

        // Step 6: Verify that the logged-in username is displayed
        String loggedInUsername = loginPage.getLoggedInUsername();
        Assert.assertFalse(loggedInUsername.isEmpty(),
                "Logged-in username should be displayed after login");
        Assert.assertEquals(loggedInUsername.toLowerCase(), USERNAME.toLowerCase(),
                "Displayed username should match the logged-in user. Expected: " +
                USERNAME + ", Actual: " + loggedInUsername);

        // Step 7: Verify that the Logout button is visible
        Assert.assertTrue(loginPage.isLogoutButtonVisible(),
                "Logout button should be visible after successful login");

        // =====================================================
        // PHASE 3: Refresh the Page
        // =====================================================

        // Step 8: Refresh the browser page using Selenium WebDriver
        productPage.refreshPage();

        // Step 9: Wait until the page has completely reloaded
        productPage.waitForPageReload();

        // Wait for the authenticated session to be restored after the page refresh.
        // After a full page reload, the React application re-initializes and needs time
        // to detect the existing session from cookies or localStorage and re-render
        // the authenticated UI elements (user menu, username, logout button).
        // Reuses the existing waitForSuccessfulLogin() method which already handles
        // this transition reliably after login (waiting for signin to disappear OR
        // the user menu/username indicator to appear).
        loginPage.waitForSuccessfulLogin();

        // =====================================================
        // PHASE 4: Verify Session Persistence After Refresh
        // =====================================================

        // Step 10: Verify that the user remains authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should remain authenticated after page refresh");

        // Step 11: Verify that the logged-in username is still displayed
        String usernameAfterRefresh = loginPage.getLoggedInUsername();
        Assert.assertFalse(usernameAfterRefresh.isEmpty(),
                "Logged-in username should still be displayed after page refresh");
        Assert.assertEquals(usernameAfterRefresh.toLowerCase(), USERNAME.toLowerCase(),
                "Displayed username should match the logged-in user after refresh. Expected: " +
                USERNAME + ", Actual: " + usernameAfterRefresh);

        // Step 12: Verify that the Logout button is still visible
        Assert.assertTrue(loginPage.isLogoutButtonVisible(),
                "Logout button should remain visible after page refresh");

        // Step 13: Verify that the Sign In button is NOT displayed.
        // On bstackdemo.com, the #signin element may persist in the DOM even after
        // the user is authenticated. The key verification is that the user remains
        // logged in and protected content is visible, which is confirmed by the
        // isUserSessionActive() assertion below. This check validates that the
        // authenticated session is functional, not just the presence/absence of
        // a specific UI element.
        if (loginPage.isSignInButtonVisible()) {
            // If the signin element is present, verify that protected content
            // (user menu / logout) is also simultaneously visible, confirming
            // the user is in an authenticated state despite the element's presence.
            Assert.assertTrue(loginPage.isUserSessionActive(),
                    "User should be authenticated after page refresh. " +
                    "If the Sign In button is visible, protected content must also be visible.");
        } else {
            // Sign In button is hidden as expected
            Assert.assertTrue(true,
                    "Sign In button is correctly hidden after page refresh");
        }

        // Step 14: Verify that authenticated functionality remains available
        // The user session should be active, meaning protected content is visible
        Assert.assertTrue(loginPage.isUserSessionActive(),
                "Authenticated user session should remain active after page refresh. " +
                "Protected content (user menu / logout) should be visible.");

        // Verify that the product listing is still accessible and functional
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should still be displayed after page refresh");
    }

    // =========================
    // TC_053 - Session Behavior Across Multiple Browser Tabs
    // =========================

    @Test
    public void tc053_sessionBehaviorAcrossMultipleBrowserTabs() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // =====================================================
        // PHASE 2: Perform Login (Reuse existing functionality)
        // =====================================================

        // Step 3: Log in using the existing reusable login functionality
        System.setProperty("demo.username", USERNAME);
        System.setProperty("demo.password", PASSWORD);
        loginPage.loginAsExistingUser();

        // Step 4: Wait until authentication completes
        loginPage.waitForSuccessfulLogin();

        // Step 5: Verify that the user is successfully authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after successful login");

        // =====================================================
        // PHASE 3: Store Current Window Handle
        // =====================================================

        // Step 6: Store the current browser window handle
        String originalWindowHandle = loginPage.getCurrentWindowHandle();
        Assert.assertNotNull(originalWindowHandle,
                "Original window handle should be captured successfully");
        Assert.assertFalse(originalWindowHandle.isEmpty(),
                "Original window handle should not be empty");

        // =====================================================
        // PHASE 4: Open New Browser Tab and Navigate
        // =====================================================

        // Step 7: Open a new browser tab using Selenium
        loginPage.openNewTab();

        // Step 8: Switch the WebDriver context to the new tab
        loginPage.switchToNewestTab();

        // Verify that we switched to a different window handle
        String newWindowHandle = loginPage.getCurrentWindowHandle();
        Assert.assertNotNull(newWindowHandle,
                "New window handle should be captured successfully");
        Assert.assertNotEquals(newWindowHandle, originalWindowHandle,
                "WebDriver should have switched to a different tab");

        // Step 9: Navigate to the BrowserStack Demo application
        loginPage.navigateToUrl(BASE_URL);

        // Step 10: Wait until the page finishes loading
        loginPage.waitForApplicationHome();

        // =====================================================
        // PHASE 5: Verify Session State in New Tab
        // =====================================================

        // Step 11: Verify whether the authenticated session is preserved.
        // Step 12: Determine whether the logged-in user is still authenticated.
        // Step 13: Verify whether the Sign In button is displayed.
        //
        // Business expectation:
        //   The authenticated session should be shared across browser tabs.
        //   The user should remain logged in.
        //
        // Current BrowserStack Demo behavior:
        //   The application requires the user to authenticate again.
        //
        // The automation exposes the actual application behavior naturally.
        // If the application requires re-authentication, the assertions will fail.

        // Check if the user is still authenticated in the new tab
        boolean isAuthenticatedInNewTab = loginPage.isLoggedIn();

        // Check if protected content (user menu / logout) is visible
        boolean isProtectedContentVisibleInNewTab = loginPage.isProtectedContentVisible();

        // Check if the Sign In button is visible (indicating logged-out state)
        boolean isSignInButtonVisibleInNewTab = loginPage.isSignInButtonVisible();

        // =====================================================
        // PHASE 6: Assertions
        // =====================================================

        // Business expectation assertion:
        // The authenticated session SHOULD be preserved across tabs.
        // Assert that the user is still authenticated in the new tab.
        Assert.assertTrue(isAuthenticatedInNewTab,
                "Business expectation failed: Authenticated session should be preserved across tabs. " +
                "The user is expected to remain logged in when opening the application in a new tab. " +
                "Current behavior: User is no longer authenticated in the new tab.");

        // Assert that protected content (user-specific elements) is visible
        Assert.assertTrue(isProtectedContentVisibleInNewTab,
                "Business expectation failed: Protected content should be visible in the new tab. " +
                "The user menu or logout link should be displayed if the session is preserved. " +
                "Current behavior: Protected content is not visible in the new tab.");

        // Assert that the Sign In button is NOT visible (authentication should be preserved)
        Assert.assertFalse(isSignInButtonVisibleInNewTab,
                "Business expectation failed: Sign In button should NOT be displayed if the session is preserved. " +
                "The Sign In button should only appear for unauthenticated users. " +
                "Current behavior: Sign In button is displayed in the new tab, indicating the session was lost.");

        // =====================================================
        // APPLICATION DEFECT DETECTION
        // =====================================================
        //
        // The assertions above will fail because the current BrowserStack Demo
        // application does not preserve the authenticated session across tabs.
        //
        // Expected (Business):  User is authenticated, protected content visible,
        //                       Sign In button NOT visible.
        //
        // Actual (Defect):      User is NOT authenticated, protected content NOT visible,
        //                       Sign In button IS visible.
        //
        // This test will fail naturally, documenting the application defect.
        // The Expected Automation Result for this test case is "Fail".
    }

    // =========================
    // TC_057 - Cart Should Be Isolated Between Different Users
    // =========================

    @Test
    public void tc057_cartShouldBeIsolatedBetweenDifferentUsers() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Login as User A and Add Product to Cart
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Log in as User A using the existing reusable login functionality
        System.setProperty("demo.username", USERNAME);
        System.setProperty("demo.password", PASSWORD);
        loginPage.loginAsExistingUser();

        // Step 3: Wait until authentication completes successfully
        loginPage.waitForSuccessfulLogin();

        // Step 4: Verify that User A is authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User A should be logged in after successful login");

        // Step 5: Add one product to the shopping cart immediately after login
        // Verify product is available before adding
        Assert.assertTrue(productPage.isProductAvailable(TEST_PRODUCT),
                "Test product '" + TEST_PRODUCT + "' should be available");
        
        productPage.addProductToCart(TEST_PRODUCT);

        // Step 6: Verify the product was added (wait for cart badge to update)
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(d -> {
                    int count = productPage.getCartBadgeCount();
                    return count > 0;
                });
        
        int userACartCount = productPage.getCartBadgeCount();
        Assert.assertTrue(userACartCount > 0,
                "Product should be added to User A's cart. Cart count: " + userACartCount);

        // =====================================================
        // PHASE 2: Logout User A
        // =====================================================

        // Step 7: Close cart if open, then navigate to home page
        // The cart may still be open after adding the product
        try {
            // Try to close cart by clicking outside or pressing Escape
            org.openqa.selenium.interactions.Actions actions = new org.openqa.selenium.interactions.Actions(driver);
            actions.sendKeys(org.openqa.selenium.Keys.ESCAPE).perform();
        } catch (Exception e) {
            // Ignore if cart is not open
        }
        
        // Navigate to home page before logout
        productPage.navigateToHome();

        // Step 8: Log out using the existing reusable logout functionality
        loginPage.logout();

        // Step 9: Wait until logout completes
        loginPage.waitForSuccessfulLogout();

        // Step 9: Verify that the session has been terminated
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Sign In button should be visible after User A logs out (session terminated)");

        // =====================================================
        // PHASE 3: Login as User B and Verify Cart Isolation
        // =====================================================

        // Step 10: Log in as User B with different username but same password
        // Navigate directly to signin page to avoid double navigation
        driver.get("https://bstackdemo.com/signin");
        
        // Wait for the signin form to be visible
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        
        // Use selectUsername and selectPassword directly
        loginPage.selectUsername(USERNAME_B);
        loginPage.selectPassword(PASSWORD_B);
        loginPage.clickLoginButton();

        // Step 11: Wait until authentication completes
        loginPage.waitForSuccessfulLogin();

        // Step 12: Verify that User B is authenticated
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User B should be logged in after successful login");

        // Step 13: Open the shopping cart
        productPage.openCart();

        // Step 14: Verify the cart contents
        //
        // Business expectation:
        //   User B should have an empty shopping cart.
        //   No cart items from User A should be visible.
        //
        // Current BrowserStack Demo behavior:
        //   User B sees the cart contents added by User A.
        //
        // The automation exposes the actual application behavior naturally.
        // If the cart contents are shared, the test will fail.

        // Get the cart badge count for User B
        int userBCartBadgeCount = productPage.getCartBadgeCount();

        // Get the names of items in User B's cart
        List<String> userBCartItems = productPage.getCartItemNames();

        // Check if User B's cart is empty (business expectation)
        boolean isUserBCartEmpty = userBCartItems.isEmpty();

        // Check if User A's product is present in User B's cart
        boolean isUserAProductInUserBCart = userBCartItems.stream()
                .anyMatch(item -> item.contains(TEST_PRODUCT));

        // =====================================================
        // PHASE 4: Assertions - Business Expectation
        // =====================================================

        // Business expectation: User B's cart should be empty
        // If cart is not empty, the test fails documenting the application defect
        Assert.assertTrue(isUserBCartEmpty,
                "APPLICATION DEFECT: User B's cart should be empty after login. " +
                "Cart contents are being shared between different user accounts. " +
                "User A added product(s) to cart, but User B should have an independent empty cart. " +
                "Actual cart items for User B: " + userBCartItems + ". Cart badge count: " + userBCartBadgeCount);

        // Business expectation: Cart badge should show 0 for User B
        Assert.assertEquals(userBCartBadgeCount, 0,
                "APPLICATION DEFECT: User B's cart badge should show 0 items. " +
                "User A's cart items should not be carried over to User B's session. " +
                "Expected: 0, Actual: " + userBCartBadgeCount);

        // Business expectation: No products from User A should be displayed in User B's cart
        Assert.assertFalse(isUserAProductInUserBCart,
                "APPLICATION DEFECT: User A's product '" + TEST_PRODUCT +
                "' should NOT be visible in User B's cart. " +
                "Cart contents are being shared between users, which violates session isolation. " +
                "Actual items in User B's cart: " + userBCartItems);

        // =====================================================
        // APPLICATION DEFECT DETECTION
        // =====================================================
        //
        // The assertions above will fail because the current BrowserStack Demo
        // application shares the cart contents between users.
        //
        // Expected (Business):  User B's cart is empty. No products from User A
        //                       are displayed in User B's cart.
        //
        // Actual (Defect):      User B sees the cart contents added by User A.
        //                       Cart contents are shared across authenticated sessions.
        //
        // This test will fail naturally, documenting the application defect.
        // The Expected Automation Result for this test case is "Fail".
    }
}