package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

import java.util.List;

/**
 * Test class for Sort functionality.
 * TC_035: Price Sorting Logic
 * Verifies that selecting "Lowest to highest" from the Order By dropdown
 * correctly sorts all displayed products by ascending price.
 */
public class SortTests extends BaseTest {

    private static final String SORT_OPTION_LOWEST_TO_HIGHEST = "Lowest to highest";

    // =========================
    // TC_035 – Price Sorting Logic
    // =========================

    @Test
    public void tc035_priceSortingLogic() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Verify that the "Order By" dropdown is visible and enabled
        Assert.assertTrue(productPage.isSortDropdownVisible(),
                "Order By dropdown should be visible on the Product Listing page");
        Assert.assertTrue(productPage.isSortDropdownEnabled(),
                "Order By dropdown should be enabled and interactable");

        // 3. Record the product prices before sorting (optional, useful for debugging)
        List<Double> pricesBeforeSort = productPage.getVisibleProductPrices();

        // 4. & 5. Open the Order By dropdown and select "Lowest to highest"
        productPage.selectSortingOption(SORT_OPTION_LOWEST_TO_HIGHEST);

        // 6. Wait until the sorting operation has completely finished
        productPage.waitForSortingToComplete();

        // 7. Retrieve the prices of every visible product after sorting
        List<Double> pricesAfterSort = productPage.getVisibleProductPrices();

        // 8. Verify that all prices are displayed correctly
        Assert.assertFalse(pricesAfterSort.isEmpty(),
                "At least one product price should be displayed after sorting");

        // 9. Verify that the list contains at least two products
        int visibleProductCount = productPage.getVisibleProductCount();
        Assert.assertTrue(visibleProductCount >= 2,
                "At least two products should be displayed for price sorting validation. Found: " + visibleProductCount);

        // 10. Verify that the displayed prices are in ascending numerical order
        Assert.assertTrue(productPage.arePricesSortedAscending(),
                "Product prices should be sorted in ascending order after selecting 'Lowest to highest'. " +
                "Prices found: " + pricesAfterSort);

        // Additional assertions for comprehensive validation

        // Verify that the sorting option "Lowest to highest" is successfully selected
        Assert.assertTrue(productPage.isSortOptionSelected(SORT_OPTION_LOWEST_TO_HIGHEST),
                "The sorting option 'Lowest to highest' should be selected in the dropdown");

        // Verify that the product list remains visible after sorting
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product list should remain visible after sorting");

        // Verify that no product disappears unexpectedly (count should remain the same)
        Assert.assertEquals(pricesAfterSort.size(), pricesBeforeSort.size(),
                "The number of products should remain the same after sorting. " +
                "Before: " + pricesBeforeSort.size() + ", After: " + pricesAfterSort.size());

        // Verify that every displayed product has a valid price
        for (int i = 0; i < pricesAfterSort.size(); i++) {
            Assert.assertTrue(pricesAfterSort.get(i) > 0,
                    "Product at position " + (i + 1) + " should have a valid positive price. " +
                    "Found: " + pricesAfterSort.get(i));
        }
    }
}