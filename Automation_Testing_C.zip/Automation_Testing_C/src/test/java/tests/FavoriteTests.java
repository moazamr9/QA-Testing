package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductPage;

/**
 * Test class for Favorite functionality.
 * TC_024: Verifies adding a product to Favorites from the Product Listing page.
 * TC_039: Verifies that products added to the Favorites list remain saved after logout/login.
 */
public class FavoriteTests extends BaseTest {

    private static final String IPHONE_12 = "iPhone 12";

    // =========================
    // TC_024 – Favorite Sync
    // =========================

    @Test
    public void tc024_favoriteSync() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // 1. Open BrowserStack Demo
        // (Handled by BaseTest.setUp())

        // 2. Verify the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(), 
                "Product Listing page should be displayed on initial load");

        // 3. Log in using the existing login functionality
        loginPage.loginAsExistingUser();

        // 4. Wait until login completes successfully
        loginPage.waitForSuccessfulLogin();

        // 5. Verify the user is logged in
        Assert.assertTrue(loginPage.isLoggedIn(), 
                "User should be logged in after login");

        // 6. Locate the product card for "iPhone 12"
        Assert.assertTrue(productPage.isProductAvailable(IPHONE_12), 
                "iPhone 12 product should be available on the page");

        // 7. Locate the Heart (Favorite) icon that belongs ONLY to the iPhone 12 product card
        // 8. Verify the Heart icon is visible
        Assert.assertTrue(productPage.isFavoriteIconVisible(IPHONE_12), 
                "Favorite icon for iPhone 12 should be visible");

        // 9. Verify the Heart icon is clickable
        Assert.assertTrue(productPage.isFavoriteIconClickable(IPHONE_12), 
                "Favorite icon for iPhone 12 should be clickable");

        // 10. Click the Heart icon
        productPage.clickFavoriteIcon(IPHONE_12);

        // 11. Wait until the Favorite state changes
        productPage.waitForFavoriteIconToBecomeActive(IPHONE_12);

        // 12. Navigate to the Favorites page
        productPage.openFavorites();

        // 13. Wait until the Favorites page finishes loading
        // (Handled by openFavorites() method)

        // 14. Verify that iPhone 12 appears inside the Favorites page
        Assert.assertTrue(productPage.isProductDisplayedInFavorites(IPHONE_12), 
                "iPhone 12 should be displayed in the Favorites page");

        // 15. Verify that the Heart icon remains active
        Assert.assertTrue(productPage.isFavoriteIconActiveOnFavoritesPage(IPHONE_12), 
                "Favorite icon for iPhone 12 should remain active on Favorites page");
    }

    // =========================
    // TC_039 – Favorites Persistence
    // =========================

    @Test
    public void tc039_favoritesPersistence() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // 1. Verify the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Login using the existing reusable login methods
        loginPage.loginAsExistingUser();

        // 3. Verify login succeeds
        loginPage.waitForSuccessfulLogin();
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after login");

        // 4. Locate the iPhone 12 product
        Assert.assertTrue(productPage.isProductAvailable(IPHONE_12),
                "iPhone 12 product should be available on the page");

        // 5. Verify its Favorite (heart) icon is visible
        Assert.assertTrue(productPage.isFavoriteIconVisible(IPHONE_12),
                "Favorite icon for iPhone 12 should be visible");

        // 6. Click the Favorite icon
        productPage.clickFavoriteIcon(IPHONE_12);

        // 7. Wait until the Favorite icon changes to the active state
        productPage.waitForFavoriteIconToBecomeActive(IPHONE_12);

        // 8. Verify the product is marked as a favorite
        Assert.assertTrue(productPage.isFavoriteIconActive(IPHONE_12),
                "Favorite icon for iPhone 12 should be active after clicking");

        // 9. Open the Favorites page
        productPage.openFavorites();

        // 10. Verify the product appears in the Favorites list
        Assert.assertTrue(productPage.isProductDisplayedInFavorites(IPHONE_12),
                "iPhone 12 should be displayed in the Favorites page");

        // 11. Logout using the existing reusable logout method
        loginPage.logout();

        // 12. Verify logout completed successfully
        Assert.assertTrue(loginPage.isLoggedOut(),
                "User should be logged out after clicking logout");

        // 13. Login again using the same account
        loginPage.loginAsExistingUser();

        // 14. Wait until login completes successfully
        loginPage.waitForSuccessfulLogin();

        // 15. Open the Favorites page again
        productPage.openFavorites();

        // 16. Verify whether the previously favorited product still exists
        // and verify whether its Favorite icon remains active
        // Note: This test is expected to fail because the application has a known defect
        // where Favorites are cleared after logout
        Assert.assertTrue(productPage.isProductDisplayedInFavorites(IPHONE_12),
                "iPhone 12 should still be displayed in the Favorites page after re-login (Favorites Persistence)");

        // 17. Verify whether its Favorite icon remains active
        Assert.assertTrue(productPage.isFavoriteIconActiveOnFavoritesPage(IPHONE_12),
                "Favorite icon for iPhone 12 should remain active after re-login (Favorites Persistence)");
    }
}