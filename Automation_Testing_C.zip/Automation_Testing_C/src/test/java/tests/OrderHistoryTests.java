package tests;

import base.BaseTest;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.OrderHistoryPage;
import pages.ProductPage;

/**
 * Test class for Order History functionality (TC_037, TC_038).
 * TC_037: Verifies that a logged-in user can access the Order History page and view previous purchases.
 * TC_038: Verifies that the displayed order information is accurate by validating
 *         the Order ID, Order Date, and Order Price on the Order History page.
 *         The test first places a new order to ensure order data exists for verification.
 */
public class OrderHistoryTests extends BaseTest {

    // Test data constants
    private static final String TEST_PRODUCT = "iPhone 12";
    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doe";
    private static final String ADDRESS = "123 Main Street";
    private static final String STATE_PROVINCE = "California";
    private static final String POSTAL_CODE = "90210";

    // =========================
    // TC_037 - View Order History
    // =========================

    @Test
    public void tc037_viewOrderHistory() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);

        // Step 1: Verify the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 2: Login using the existing reusable login methods
        loginPage.loginAsExistingUser();

        // Step 3: Verify login completed successfully
        // The loginAsExistingUser() method already waits for URL navigation
        // Verify we are no longer on the signin page
        // Note: The URL may still contain "?signin=true" as a query parameter after login
        // on bstackdemo.com, so we check the path specifically, not the query string
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean notOnSigninPage = !urlPath.contains("/signin") && !urlPath.contains("/login");
        Assert.assertTrue(notOnSigninPage,
                "Login should complete and navigate away from the signin page. Current URL: " + currentUrl);

        // Step 4: Verify the user is authenticated
        // Wait explicitly for the logout link to appear (15-second timeout) before checking
        loginPage.waitForSuccessfulLogin();

        // The logout link is the standard indicator of successful login
        // If logout link is not found, the test will fail with a clear message
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after login. Logout link should be visible.");

        // Step 5: Locate the "Orders" navigation link or button
        Assert.assertTrue(orderHistoryPage.isOrdersLinkPresent(),
                "Orders navigation link or button should exist in the DOM");

        // Step 6: Verify the Orders control is visible
        Assert.assertTrue(orderHistoryPage.isOrdersLinkVisible(),
                "Orders navigation control should be visible");

        // Step 7: Verify the Orders control is enabled
        Assert.assertTrue(orderHistoryPage.isOrdersLinkEnabled(),
                "Orders navigation control should be enabled");

        // Step 8: Click the Orders control
        orderHistoryPage.clickOrders();

        // Step 9: Wait for navigation to complete
        orderHistoryPage.waitForOrdersPage();

        // Step 10: Verify the Order History page is displayed
        Assert.assertTrue(orderHistoryPage.isOrdersPageDisplayed(),
                "Order History page should be displayed after clicking Orders link");

        // Step 11: Verify an order list or order table is present
        Assert.assertTrue(orderHistoryPage.isOrderListDisplayed(),
                "Order list or order table should be present on the Order History page");

        // Step 12: Verify at least one order is displayed
        // Note: If the user has no orders, the test will fail with a clear message
        Assert.assertTrue(orderHistoryPage.hasOrders(),
                "At least one order should be displayed in the Order History. " +
                "If no orders exist, the application should display an appropriate message.");
    }

    // =========================
    // TC_038 - Order Details Accuracy
    // =========================

    @Test
    public void tc038_orderDetailsAccuracy() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);

        // =====================================================
        // PHASE 1: Login (Reuse existing login logic from TC_037)
        // =====================================================

        // Step 1: Verify the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 2: Login using the existing reusable login methods
        loginPage.loginAsExistingUser();

        // Step 3: Verify login completed successfully
        String currentUrl = driver.getCurrentUrl();
        String urlPath = (currentUrl != null) ? currentUrl : "";
        int queryIndex = urlPath.indexOf('?');
        if (queryIndex >= 0) {
            urlPath = urlPath.substring(0, queryIndex);
        }
        boolean notOnSigninPage = !urlPath.contains("/signin") && !urlPath.contains("/login");
        Assert.assertTrue(notOnSigninPage,
                "Login should complete and navigate away from the signin page. Current URL: " + currentUrl);

        // Step 4: Verify the user is authenticated
        loginPage.waitForSuccessfulLogin();
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after login. Logout link should be visible.");

        // =====================================================
        // PHASE 2: Place a new order to ensure order data exists
        // =====================================================

        // Step 5: Add "iPhone 12" to the shopping cart by clicking its "Add to Cart" button
        productPage.addProductToCart(TEST_PRODUCT);

        // Step 6: Proceed to checkout (opens the cart and clicks the checkout button)
        productPage.proceedToCheckout();

        // Step 7: Fill in the checkout/shipping details and place the order
        productPage.placeOrder(FIRST_NAME, LAST_NAME, ADDRESS, STATE_PROVINCE, POSTAL_CODE);

        // Step 8: Wait for and verify the order confirmation page is displayed
        productPage.waitForOrderConfirmation();
        Assert.assertTrue(productPage.isOrderConfirmationDisplayed(),
                "Your Order has been successfully placed.");

        // Step 9: Extract the order number from the confirmation page
        String orderNumber = productPage.getOrderNumber();
        Assert.assertFalse(orderNumber.isEmpty(),
                "Order number should be displayed on the confirmation page");

        // Step 10: Return to the product listing page using "Continue Shopping"
        productPage.clickContinueShopping();

        // =====================================================
        // PHASE 3: Navigate to Orders Page (Reuse TC_037 logic)
        // =====================================================

        // Step 11: Navigate to the Orders page using existing methods
        Assert.assertTrue(orderHistoryPage.isOrdersLinkPresent(),
                "Orders navigation link or button should exist in the DOM");
        Assert.assertTrue(orderHistoryPage.isOrdersLinkVisible(),
                "Orders navigation control should be visible");
        Assert.assertTrue(orderHistoryPage.isOrdersLinkEnabled(),
                "Orders navigation control should be enabled");
        orderHistoryPage.clickOrders();

        // Step 12: Wait until the Order History page is fully loaded
        orderHistoryPage.waitForOrdersPage();
        orderHistoryPage.waitForPageLoad();

        // Step 13: Verify the Orders page is displayed
        Assert.assertTrue(orderHistoryPage.isOrdersPageDisplayed(),
                "Order History page should be displayed after clicking Orders link");

        // Step 14: Verify the order list is displayed
        Assert.assertTrue(orderHistoryPage.isOrderListDisplayed(),
                "Order list should be present on the Order History page");

        // Step 15: Verify at least one order is displayed
        Assert.assertTrue(orderHistoryPage.hasOrders(),
                "At least one order should be displayed in the Order History");

        // =====================================================
        // PHASE 4: Validate Order Details
        // =====================================================

        // Step 16: Find the most recent order (the one we just placed) by looking for the product name
        // The order history page shows "Title: iPhone 12" for the product
        WebElement orderElement = orderHistoryPage.getOrderById(TEST_PRODUCT);
        Assert.assertNotNull(orderElement,
                "Order element for " + TEST_PRODUCT + " should not be null");

        // Step 17: Retrieve the displayed Order ID from the order
        String actualOrderId = orderHistoryPage.getOrderId(orderElement);

        // Step 18: Verify that the Order ID is displayed and not empty (if present)
        // Note: The order history page may not display the order ID, so we check if it's present
        if (!actualOrderId.isEmpty()) {
            Assert.assertTrue(actualOrderId.matches(".*#\\d+.*") || actualOrderId.matches(".*\\d+.*"),
                    "Displayed Order ID should contain a valid order number. Actual: '" + actualOrderId + "'");
        }

        // Step 20: Retrieve the displayed Order Date from the order
        String actualOrderDate = orderHistoryPage.getOrderDate(orderElement);

        // Step 21: Verify that the Order Date is displayed and not empty
        Assert.assertFalse(actualOrderDate.isEmpty(),
                "Order Date should be displayed and not empty. " +
                "Expected a valid date string for order");

        // Step 22: Verify the Order Date is visible (not null)
        Assert.assertNotNull(actualOrderDate,
                "Order Date should be visible for the order");

        // Step 23: Retrieve the displayed Order Price from the order
        String actualOrderPrice = orderHistoryPage.getOrderPrice(orderElement);

        // Step 24: Verify that the Order Price is displayed and not empty
        Assert.assertFalse(actualOrderPrice.isEmpty(),
                "Order Price should be displayed and not empty. " +
                "Expected a valid price string for order");

        // Step 25: Verify the Order Price is visible (not null)
        Assert.assertNotNull(actualOrderPrice,
                "Order Price should be visible for the order");

        // Step 26: Verify that the price is correctly formatted as a currency value
        boolean isPriceFormatted = orderHistoryPage.isOrderPriceFormatted(orderElement);
        Assert.assertTrue(isPriceFormatted,
                "Order Price should be correctly formatted as a currency value. " +
                "Actual price text: '" + actualOrderPrice + "'");

        // Step 27: Verify that the displayed order information is internally consistent
        // The order element should contain the product name, date, and price
        String orderDetailsText = orderElement.getText();
        Assert.assertTrue(orderDetailsText.contains(TEST_PRODUCT),
                "Order details should contain the product name '" + TEST_PRODUCT + "'");
        Assert.assertTrue(actualOrderDate.isEmpty() || orderDetailsText.contains(actualOrderDate),
                "Order details should contain the Order Date");
        Assert.assertTrue(actualOrderPrice.isEmpty() || orderDetailsText.contains(actualOrderPrice),
                "Order details should contain the Order Price");
    }
}