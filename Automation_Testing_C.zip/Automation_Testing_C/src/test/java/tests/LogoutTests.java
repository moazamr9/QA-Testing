package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductPage;

/**
 * Test class for Logout functionality (TC_051).
 * TC_051: Verifies that a logged-in user can successfully log out of the BrowserStack
 *         Demo application and that the authenticated session is properly terminated.
 */
public class LogoutTests extends BaseTest {

    private static final String USERNAME = "demouser";
    private static final String PASSWORD = "testingisfun99";

    @Test
    public void tc051_logoutFromTheSystem() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 10: Verify that the Sign In button is visible again (guest state)
        // Also verifies precondition: user is not logged in
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Perform Login (reuse existing functionality)
        // =====================================================

        // Step 3: Log in using existing reusable login functionality
        // Use system properties so we reuse loginAsExistingUser() without duplicating login logic.
        System.setProperty("demo.username", USERNAME);
        System.setProperty("demo.password", PASSWORD);

        loginPage.loginAsExistingUser();

        // Step 4: Wait until authentication completes
        loginPage.waitForSuccessfulLogin();

        // Step 5: Verify that the user is successfully logged in
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after successful login");

        // Step 11: Verify that the logged-in username is displayed
        String loggedInUsername = loginPage.getLoggedInUsername();
        Assert.assertFalse(loggedInUsername.isEmpty(),
                "Logged-in username should be displayed after login");

        // =====================================================
        // PHASE 3: Logout
        // =====================================================

        // Step 6: Verify that the user is logged in before logout
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after successful login (required before logout)");

        // Step 7: Click the Logout button
        // Logout is performed from the home/product listing page (not inside the signin modal).
        productPage.navigateToHome();
        loginPage.logout();

        // Step 8: Wait until the logout operation completes
        loginPage.waitForSuccessfulLogout();




        // =====================================================
        // PHASE 4: Verify Post-Logout (Guest State)
        // =====================================================

        // Step 9: Verify that the authenticated session has been terminated
        // Validate guest state via authoritative UI: Sign In visible.
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Sign In button should be visible after logout (guest state)");


        // Step 11: Verify that the logged-in username is no longer displayed.
        // UI may keep text in DOM briefly; best indicator is that user is in guest mode (Sign In visible).
        Assert.assertTrue(loginPage.isSignInButtonVisible(),
                "Guest state expected after logout (Sign In should be visible)");




        // Step 12: Verify that the Logout button is no longer visible
        Assert.assertTrue(driver.findElements(org.openqa.selenium.By.id("logout")).stream()
                        .noneMatch(org.openqa.selenium.WebElement::isDisplayed),
                "Logout button should not be visible after logout");

        // Step 13: Verify that the Product Listing page is displayed as a guest user
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed after logout as a guest user");
    }
}

