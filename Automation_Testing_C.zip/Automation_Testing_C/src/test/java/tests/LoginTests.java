package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductPage;

import java.time.Duration;

/**
 * Test class for Login functionality (TC_041).
 * TC_041: Verifies that a registered user can successfully log into the BrowserStack Demo
 *         application using valid credentials and validates all post-login behaviors.
 */
public class LoginTests extends BaseTest {

    // =========================
    // TC_041 - Login with Valid Credentials
    // =========================

    @Test
    public void tc041_loginWithValidCredentials() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Credentials
        // =====================================================

        // Step 6: Verify that the Username dropdown is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username dropdown should be visible on the login page");

        // Step 7: Select the username: demouser
        loginPage.selectUsername("demouser");

        // Step 8: Verify that the Password dropdown is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password dropdown should be visible on the login page");

        // Step 9: Select the password: testingisfun99
        loginPage.selectPassword("testingisfun99");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after selecting credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Perform Login
        // =====================================================

        // Step 11: Click the Login button
        loginPage.clickLoginButton();

        // Step 12: Wait until authentication completes
        // The clickLoginButton() method already waits for URL navigation
        // Additional wait to ensure all post-login elements are updated
        loginPage.waitForSuccessfulLogin();

        // =====================================================
        // PHASE 5: Verify Post-Login State
        // =====================================================

        // Step 13: Verify that the Login modal closes
        // Verify login completed successfully by checking URL
        // Note: The URL may still contain "?signin=true" as a query parameter after login
        // on bstackdemo.com, so we check the path specifically, not the query string
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean notOnSigninPage = !urlPath.contains("/signin") && !urlPath.contains("/login");
        Assert.assertTrue(notOnSigninPage,
                "Login should complete and navigate away from the signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the user is logged in
        // The waitForSuccessfulLogin() above already waited for the logout link to appear
        // The logout link is the standard indicator of successful login
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after login. Logout link should be visible.");

        // Step 15: Verify that the displayed username matches the logged-in account
        // Wait for the username to be displayed and verify it
        String loggedInUsername = loginPage.getLoggedInUsername();
        Assert.assertFalse(loggedInUsername.isEmpty(),
                "Logged-in username should be displayed after login");
        Assert.assertEquals(loggedInUsername, "demouser",
                "Displayed username should match the logged-in account");

        // Step 16: Verify that the Product Listing page is displayed after login
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed after successful login");
    }

    // =========================
    // TC_042 - Login with Invalid Password
    // =========================

    @Test
    public void tc042_loginWithInvalidPassword() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Invalid Credentials
        // =====================================================

        // Step 6: Verify that the Username dropdown is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username dropdown should be visible on the login page");

        // Step 7: Select the username: demouser
        loginPage.selectUsername("demouser");

        // Step 8: Verify that the Password dropdown is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password dropdown should be visible on the login page");

        // Step 9: Select the invalid password: wrongpassword
        // Note: The BrowserStack Demo application uses React-Select dropdowns with predefined values
        // We select "wrongpassword" which is not a valid password to trigger the error
        loginPage.selectPassword("wrongpassword");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after selecting credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Invalid Credentials
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() because invalid login won't navigate away
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the login response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 13: Verify that the login attempt is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the expected error message is displayed
        // Wait for and retrieve the error message
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertTrue(errorMessage.contains("Invalid Password") || errorMessage.contains("Invalid") || errorMessage.contains("incorrect"),
                "Error message should indicate invalid credentials. Actual message: " + errorMessage);

        // Step 15: Verify that the login modal remains open
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed(),
                "Login modal should remain open after failed login attempt");

        // Step 16: Verify that the user is not authenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt");

        // Step 17: Verify that the Product Listing page remains accessible as a guest user
        // Navigate back to the product listing page
        driver.get("https://bstackdemo.com/");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".shelf-container")));
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain accessible as a guest user after failed login");
    }

    // =========================
    // TC_043 - Login with Invalid Username
    // =========================

    @Test
    public void tc043_loginWithInvalidUsername() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Invalid Credentials
        // =====================================================

        // Step 6: Verify that the Username field/dropdown is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username dropdown should be visible on the login page");

        // Step 7: Enter or select the invalid username: wronguser
        // Note: The BrowserStack Demo application uses React-Select dropdowns with predefined values
        // We select "wronguser" which is not a valid username to trigger the error
        loginPage.selectUsername("wronguser");

        // Step 8: Verify that the Password field/dropdown is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password dropdown should be visible on the login page");

        // Step 9: Enter or select the password: testingisfun99
        loginPage.selectPassword("testingisfun99");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after selecting credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Invalid Credentials
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() because invalid login won't navigate away
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 13: Verify that the login attempt is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the error message is displayed
        // Wait for and retrieve the error message
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt");

        // Step 15: Verify that the displayed error message equals: "Invalid Username"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, "Invalid Username",
                "Error message should indicate invalid username. Actual message: " + errorMessage);

        // Step 16: Verify that the user is not authenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt");

        // Step 17: Verify that the login modal remains available (or the Sign In button is still visible)
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed(),
                "Login modal should remain open after failed login attempt");

        // Step 18: Verify that the Product Listing page remains accessible as a guest user
        // Navigate back to the product listing page
        driver.get("https://bstackdemo.com/");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".shelf-container")));
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain accessible as a guest user after failed login");
    }

    // =========================
    // TC_044 - Login with Empty Fields
    // =========================

    @Test
    public void tc044_loginWithEmptyFields() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Verify Login Form Elements (No Credentials)
        // =====================================================

        // Step 6: Verify that the Username selector is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username selector should be visible on the login page");

        // Step 7: Verify that the Password selector is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password selector should be visible on the login page");

        // Step 8: Leave both Username and Password empty
        // No selection is made - credentials remain empty

        // Step 9: Verify that the Login button is enabled
        // The login button should be clickable even without credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Empty Credentials
        // =====================================================

        // Step 10: Click the Login button without selecting or entering any credentials
        // Use clickLoginButtonWithoutWait() because login with empty fields won't navigate away
        loginPage.clickLoginButtonWithoutWait();

        // Step 11: Wait for the application's validation response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 12: Verify that authentication is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 13: Verify that the displayed validation message matches the application's current behavior
        // Wait for and retrieve the error message
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt");

        // Step 14: Verify that the validation message equals "Invalid Username"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, "Invalid Username",
                "Error message should indicate invalid username. Actual message: " + errorMessage);

        // Step 15: Verify that the user remains unauthenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt");

        // Step 16: Verify that the login modal remains open or that the Sign In button is still available
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");

        // Step 17: Verify that the Product Listing page remains accessible as a guest user
        // Navigate back to the product listing page
        driver.get("https://bstackdemo.com/");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".shelf-container")));
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain accessible as a guest user after failed login");
    }

    // =========================
    // TC_045 - Login with Empty Username
    // =========================

    @Test
    public void tc045_loginWithEmptyUsername() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Verify Login Form Elements
        // =====================================================

        // Step 6: Verify that the Username selector/field is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username selector should be visible on the login page");

        // Step 7: Verify that the Password selector/field is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password selector should be visible on the login page");

        // Step 8: Leave the Username empty
        // No selection is made - username remains empty

        // Step 9: Enter or select the valid password: testingisfun99
        loginPage.selectPassword("testingisfun99");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after selecting password
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Empty Username
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() because login with empty username won't navigate away
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 13: Verify that authentication is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the validation message is displayed
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt");

        // Step 15: Verify that the displayed message equals: "Invalid Username"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, "Invalid Username",
                "Error message should indicate invalid username. Actual message: " + errorMessage);

        // Step 16: Verify that the user remains unauthenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt");

        // Step 17: Verify that the Sign In button remains available or that the Login modal remains open
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");
    }

    // =========================
    // TC_046 - Login with Empty Password
    // =========================

    @Test
    public void tc046_loginWithEmptyPassword() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Credentials
        // =====================================================

        // Step 6: Verify that the Username selector/field is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username selector should be visible on the login page");

        // Step 7: Verify that the Password selector/field is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password selector should be visible on the login page");

        // Step 8: Enter or select the valid username: demouser
        loginPage.selectUsername("demouser");

        // Step 9: Leave the Password empty
        // No selection is made - password remains empty

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable even without password
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Empty Password
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() because login with empty password won't navigate away
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 13: Verify that the login attempt is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the validation message is displayed
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt");

        // Step 15: Verify that the displayed message equals: "Invalid Password"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, "Invalid Password",
                "Error message should indicate invalid password. Actual message: " + errorMessage);

        // Step 16: Verify that the user remains unauthenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt");

        // Step 17: Verify that the Login modal remains open or that the Sign In button is still visible
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");
    }

    // =========================
    // TC_047 - Login with Password Case Sensitivity
    // =========================

    @Test
    public void tc047_loginWithPasswordCaseSensitivity() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Credentials with Incorrect Password Casing
        // =====================================================

        // Step 6: Verify that the Username selector/field is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username selector should be visible on the login page");

        // Step 7: Enter or select the username: demouser
        loginPage.selectUsername("demouser");

        // Step 8: Verify that the Password selector/field is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password selector should be visible on the login page");

        // Step 9: Enter the password with incorrect casing: Testingisfun99
        // Note: The correct password is "testingisfun99" (lowercase)
        // This test validates that passwords should be case-sensitive
        // The application currently ignores case, which is a defect
        loginPage.enterPassword("Testingisfun99");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after entering credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Perform Login
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() to handle both success and failure scenarios
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for either navigation away (success) or error message (failure)
        // The application may either:
        // - Navigate away (defect: password case is ignored)
        // - Stay on signin page with error (correct behavior)
        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlToBe("https://bstackdemo.com/"),
                ExpectedConditions.urlToBe("https://bstackdemo.com/?signin=true"),
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']"))
        ));

        // =====================================================
        // PHASE 5: Verify Authentication Result
        // =====================================================

        // Step 13: Verify whether the application authenticates the user
        // Business expectation: Authentication should fail
        // Current BrowserStack Demo behavior: Authentication succeeds (defect)
        // This assertion will fail naturally if the application defect exists
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean notOnSigninPage = !urlPath.contains("/signin") && !urlPath.contains("/login");
        Assert.assertFalse(notOnSigninPage,
                "Authentication should fail with incorrect password casing. User should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify whether the logged-in username is displayed
        // Business expectation: Username should NOT be displayed (login should fail)
        // Current BrowserStack Demo behavior: Username IS displayed (defect)
        // This assertion will fail naturally if the application defect exists
        String loggedInUsername = loginPage.getLoggedInUsername();
        Assert.assertTrue(loggedInUsername.isEmpty(),
                "Logged-in username should NOT be displayed after failed login. Actual username: " + loggedInUsername);

        // Step 15: Verify whether the Product Listing page remains accessible as an authenticated user
        // Business expectation: User should NOT be authenticated
        // Current BrowserStack Demo behavior: User IS authenticated (defect)
        // This assertion will fail naturally if the application defect exists
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should NOT be logged in with incorrect password casing. This exposes the application defect where password case is ignored.");
    }

    // =========================
    // TC_048 - Login with Username Case Sensitivity
    // =========================

    @Test
    public void tc048_loginWithUsernameCaseSensitivity() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Credentials with Incorrect Username Casing
        // =====================================================

        // Step 6: Verify that the Username field/dropdown is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username field/dropdown should be visible on the login page");

        // Step 7: Enter the username with incorrect casing: DemoUser
        // Note: The correct username is "demouser" (lowercase)
        // This test validates that usernames should be case-sensitive
        // The application currently ignores case, which is a defect
        loginPage.enterUsername("DemoUser");

        // Step 8: Verify that the Password field/dropdown is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password field/dropdown should be visible on the login page");

        // Step 9: Enter or select the valid password: testingisfun99
        loginPage.selectPassword("testingisfun99");

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after entering credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Perform Login
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() to handle both success and failure scenarios
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for either navigation away (success) or error message (failure)
        // The application may either:
        // - Navigate away (defect: username case is ignored)
        // - Stay on signin page with error (correct behavior)
        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlToBe("https://bstackdemo.com/"),
                ExpectedConditions.urlToBe("https://bstackdemo.com/?signin=true"),
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']"))
        ));

        // =====================================================
        // PHASE 5: Verify Authentication Result
        // =====================================================

        // Step 13: Verify whether the application authenticates the user
        // Business expectation: Authentication should fail
        // Current BrowserStack Demo behavior: Authentication succeeds (defect)
        // This assertion will fail naturally if the application defect exists
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean notOnSigninPage = !urlPath.contains("/signin") && !urlPath.contains("/login");
        Assert.assertFalse(notOnSigninPage,
                "Authentication should fail with incorrect username casing. User should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify whether the logged-in username is displayed
        // Business expectation: Username should NOT be displayed (login should fail)
        // Current BrowserStack Demo behavior: Username IS displayed (defect)
        // This assertion will fail naturally if the application defect exists
        String loggedInUsername = loginPage.getLoggedInUsername();
        Assert.assertTrue(loggedInUsername.isEmpty(),
                "Logged-in username should NOT be displayed after failed login. Actual username: " + loggedInUsername);

         // Step 15: Verify whether authenticated content becomes available
         // Business expectation: User should NOT be authenticated
         // Current BrowserStack Demo behavior: User IS authenticated (defect)
         // This assertion will fail naturally if the application defect exists
         Assert.assertFalse(loginPage.isLoggedIn(),
                 "User should NOT be logged in with incorrect username casing. This exposes the application defect where username case is ignored.");
     }

     // =========================
     // TC_049 - Login with SQL Injection Attempt
     // =========================

     @Test
     public void tc049_loginWithSQLInjectionAttempt() {
         ProductPage productPage = new ProductPage(driver);
         LoginPage loginPage = new LoginPage(driver);

         // SQL injection test data
         final String SQL_INJECTION_PAYLOAD = "' OR '1'='1";
         final String EXPECTED_ERROR_MESSAGE = "Invalid Username";

         // =====================================================
         // PHASE 1: Verify Initial State (Pre-Login)
         // =====================================================

         // Step 1: Launch the BrowserStack Demo application
         // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

         // Step 2: Verify that the Product Listing page is displayed
         Assert.assertTrue(productPage.isProductListingDisplayed(),
                 "Product Listing page should be displayed on initial load");

         // Step 3: Verify that the Sign In button is visible
         // The signin link should be visible when user is not logged in
         Assert.assertTrue(loginPage.isLoggedOut(),
                 "Sign In button should be visible before login (user should be logged out)");

         // =====================================================
         // PHASE 2: Open Login Modal
         // =====================================================

         // Step 4: Click the Sign In button
         loginPage.clickSignIn();

         // Step 5: Wait until the Login modal is displayed
         // The clickSignIn() method already waits for the signin form to be visible
         Assert.assertTrue(loginPage.isDisplayed(),
                 "Login modal/page should be displayed after clicking Sign In");

         // =====================================================
         // PHASE 3: Enter SQL Injection Payloads
         // =====================================================

         // Step 6: Verify that the Username field is visible
         // Wait for the username field to be visible and interactive
         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
         WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
         Assert.assertTrue(usernameField.isDisplayed(),
                 "Username field should be visible on the login page");

         // Step 7: Verify that the Password field is visible
         // Wait for the password field to be visible and interactive
         WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
         Assert.assertTrue(passwordField.isDisplayed(),
                 "Password field should be visible on the login page");

         // Step 8: Enter the SQL injection payload into the Username field
         // The application should treat this as plain text, not as SQL code
         loginPage.enterUsername(SQL_INJECTION_PAYLOAD);

         // Step 9: Enter the SQL injection payload into the Password field
         // The application should treat this as plain text, not as SQL code
         loginPage.enterPassword(SQL_INJECTION_PAYLOAD);

         // Step 10: Verify that the Login button is enabled
         // The login button should be clickable after entering credentials
         By loginButtonLocator = By.id("login-btn");
         WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
         Assert.assertTrue(loginButton.isEnabled(),
                 "Login button should be enabled on the login page");

         // =====================================================
         // PHASE 4: Attempt Login with SQL Injection Payloads
         // =====================================================

         // Step 11: Click the Login button
         // Use clickLoginButtonWithoutWait() because SQL injection login will be rejected
         loginPage.clickLoginButtonWithoutWait();

         // Step 12: Wait for the authentication response
         // Wait for the error message to appear
         wait.until(ExpectedConditions.or(
                 ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                 ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
         ));

         // =====================================================
         // PHASE 5: Verify Login Rejection and Security
         // =====================================================

         // Step 13: Verify that authentication is rejected
         // The user should remain on the signin page (URL should still contain /signin)
         String currentUrl = driver.getCurrentUrl();
         String urlPath = currentUrl.replaceAll("\\?.*$", "");
         boolean stillOnSigninPage = urlPath.contains("/signin");
         Assert.assertTrue(stillOnSigninPage,
                 "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

         // Step 14: Verify that the validation message is displayed
         Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                 "Error message should be displayed after failed login attempt");

         // Step 15: Verify that the displayed validation message equals: "Invalid Username"
         String errorMessage = loginPage.getLoginErrorMessage();
         Assert.assertFalse(errorMessage.isEmpty(),
                 "Error message should be displayed after failed login attempt");
         Assert.assertEquals(errorMessage, EXPECTED_ERROR_MESSAGE,
                 "Error message should indicate invalid username. Actual message: " + errorMessage);

         // Step 16: Verify that the user remains unauthenticated
         Assert.assertFalse(loginPage.isLoggedIn(),
                 "User should not be logged in after SQL injection attempt");

         // Step 17: Verify that the Login modal remains available or that the Sign In button is still visible
         // The signin form should still be visible after failed login
         Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                 "Login modal should remain open or Sign In button should still be visible after failed login attempt");

         // Step 18: Verify that no unexpected application error, exception page, or crash is displayed
         // Check that the page is still functional and no error pages are shown
         // The application should remain on the signin page with normal error message
         boolean noErrorPage = driver.findElements(By.cssSelector(".error-page, .exception, .server-error")).isEmpty();
         Assert.assertTrue(noErrorPage,
                 "No error page or exception should be displayed after SQL injection attempt");

         // Verify the application is still functional by checking the page title or main content
         boolean pageStillFunctional = driver.getTitle() != null && !driver.getTitle().isEmpty();
         Assert.assertTrue(pageStillFunctional,
                 "Application should remain functional after SQL injection attempt");
     }

    // =========================
    // TC_050 - Login with XSS Injection Attempt
    // =========================

    @Test
    public void tc050_loginWithXSSInjectionAttempt() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // XSS injection test data
        final String XSS_PAYLOAD = "<script>alert(1)</script>";
        final String PASSWORD = "test";
        final String EXPECTED_ERROR_MESSAGE = "Invalid Username";

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // Step 6: Verify that the Username field is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameField.isDisplayed(),
                "Username field should be visible on the login page");

        // Step 7: Verify that the Password field is visible
        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordField.isDisplayed(),
                "Password field should be visible on the login page");

        // =====================================================
        // PHASE 3: Enter XSS Payload
        // =====================================================

        // Step 8: Enter the XSS payload into the Username field
        // Application should treat it as plain text
        loginPage.enterUsername(XSS_PAYLOAD);

        // Step 9: Enter the password
        loginPage.enterPassword(PASSWORD);

        // Step 10: Verify that the Login button is enabled
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Submit Login and Validate Rejection
        // =====================================================

        // Step 11: Click the Login button
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response (error message)
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // Step 13: Verify that authentication is rejected
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the validation message is displayed
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt");

        // Step 15: Verify that the displayed message equals "Invalid Username"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, EXPECTED_ERROR_MESSAGE,
                "Error message should indicate invalid username. Actual message: " + errorMessage);

        // Step 16: Verify that the user remains unauthenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after XSS injection attempt");

        // Step 17: Verify that the Login modal remains available (or Sign In still visible)
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");

        // =====================================================
        // PHASE 5: Security Assertions (No XSS Execution)
        // =====================================================

        // Step 18: Verify that no JavaScript alert dialog appears
        Assert.assertFalse(loginPage.isJavaScriptAlertPresent(),
                "No JavaScript alert dialog should appear. XSS payload must not execute.");

        // Step 19: Verify that no application crash / unexpected error page occurs
        boolean noErrorPage = driver.findElements(By.cssSelector(".error-page, .exception, .server-error")).isEmpty();
        Assert.assertTrue(noErrorPage,
                "No error page or exception should be displayed after XSS injection attempt");

        boolean pageStillFunctional = driver.getTitle() != null && !driver.getTitle().isEmpty();
        Assert.assertTrue(pageStillFunctional,
                "Application should remain functional after XSS injection attempt");
    }

    // =========================
    // TC_054 - Login with Leading and Trailing Spaces
    // =========================

    @Test
    public void tc054_loginWithLeadingAndTrailingSpaces() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // Test data: valid credentials with trailing whitespace
        // The application should trim whitespace and authenticate successfully
        final String USERNAME_WITH_SPACE = "demouser ";
        final String PASSWORD_WITH_SPACE = "testingisfun99 ";

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Credentials with Trailing Whitespace
        // =====================================================

        // Step 6: Verify that the Username field is visible
        // Wait for the username field to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameField.isDisplayed(),
                "Username field should be visible on the login page");

        // Step 7: Verify that the Password field is visible
        // Wait for the password field to be visible and interactive
        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordField.isDisplayed(),
                "Password field should be visible on the login page");

        // Step 8: Enter the username exactly as "demouser " (including trailing space)
        // The credentials are entered without trimming so the application itself
        // determines how whitespace is handled.
        // typeUsername() is used instead of enterUsername() because enterUsername()
        // presses ENTER which causes React-Select to create/select an option.
        // typeUsername() types the text WITHOUT pressing ENTER, preserving the
        // trailing whitespace and leaving the dropdown in an unselected state.
        loginPage.typeUsername(USERNAME_WITH_SPACE);

        // Step 9: Enter the password exactly as "testingisfun99 " (including trailing space)
        // The credentials are entered without trimming so the application itself
        // determines how whitespace is handled.
        // typePassword() is used instead of enterPassword() for the same reason:
        // it types the text WITHOUT pressing ENTER, preserving trailing whitespace.
        loginPage.typePassword(PASSWORD_WITH_SPACE);

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after entering credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Perform Login
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() to handle both success and failure scenarios
        // If the application correctly trims whitespace, it will navigate away (success)
        // If the application has the defect, it will stay on the signin page (failure)
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for either navigation away (whitespace correctly handled) or error message (defect)
        // The application may either:
        // - Navigate away (correct behavior: whitespace is ignored)
        // - Stay on signin page with an error message (current behavior: whitespace is rejected)
        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlToBe("https://bstackdemo.com/"),
                ExpectedConditions.urlToBe("https://bstackdemo.com/?signin=true"),
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']"))
        ));

        // =====================================================
        // PHASE 5: Verify Authentication Result
        // =====================================================

        // Step 13: Determine whether authentication succeeds
        // Check the current URL to see if the page navigated away from /signin
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean navigatedAway = !urlPath.contains("/signin") && !urlPath.contains("/login");

        // Step 14: Capture any validation message displayed
        // If authentication fails, the application displays a validation message
        String errorMessage = loginPage.getLoginErrorMessage();

        // Step 15: Verify whether the user becomes authenticated
        // Business expectation: Leading and trailing whitespace should be ignored
        // and authentication should succeed.
        // Current BrowserStack Demo behavior: Authentication is rejected and
        // validation messages such as "Invalid Username" or "Invalid Password" are displayed.
        //
        // This assertion will fail naturally if the application rejects credentials
        // containing whitespace, exposing the application defect.
        Assert.assertTrue(navigatedAway,
                "Business expectation: Leading and trailing whitespace should be ignored. "
                + "User should be authenticated successfully. "
                + "Current BrowserStack Demo behavior: Authentication rejected. "
                + "Validation message: '" + errorMessage + "'. "
                + "User remains on signin page. Current URL: " + currentUrl);

        // If the navigation assertion above passed (whitespace was handled correctly),
        // verify the user is fully authenticated
        if (navigatedAway) {
            // Verify the user is logged in
            Assert.assertTrue(loginPage.isLoggedIn(),
                    "User should be logged in after whitespace is trimmed");

            // Verify the displayed username matches the logged-in account
            String loggedInUsername = loginPage.getLoggedInUsername();
            Assert.assertFalse(loggedInUsername.isEmpty(),
                    "Logged-in username should be displayed after successful login");
            Assert.assertEquals(loggedInUsername, "demouser",
                    "Displayed username should match the logged-in account");

            // Verify the Product Listing page is displayed after login
            Assert.assertTrue(productPage.isProductListingDisplayed(),
                    "Product Listing page should be displayed after successful login");
        }
    }

    // =========================
    // TC_055 - Login with Very Long Username and Password
    // =========================

    @Test
    public void tc055_loginWithVeryLongUsernameAndPassword() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // Test data: very long username and password (200+ characters)
        final String VERY_LONG_USERNAME = "A" + "a".repeat(200);
        final String VERY_LONG_PASSWORD = "B" + "b".repeat(200);
        final String EXPECTED_ERROR_MESSAGE = "Invalid Username";

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Very Long Credentials
        // =====================================================

        // Step 6: Verify that the Username field is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameField.isDisplayed(),
                "Username field should be visible on the login page");

        // Step 7: Verify that the Password field is visible
        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordField.isDisplayed(),
                "Password field should be visible on the login page");

        // Step 8: Enter a very long username (200+ characters) into the Username field
        // Using typeUsername() to type the text without pressing ENTER,
        // which preserves the long text without triggering React-Select option creation
        loginPage.typeUsername(VERY_LONG_USERNAME);

        // Step 9: Enter a very long password (200+ characters) into the Password field
        // Using typePassword() to type the text without pressing ENTER,
        // which preserves the long text without triggering React-Select option creation
        loginPage.typePassword(VERY_LONG_PASSWORD);

        // Step 10: Verify that the Login button is enabled
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Very Long Credentials
        // =====================================================

        // Step 11: Click the Login button
        // The application should handle the long input gracefully without crashing
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // The system should process the input without crashing and show an error message
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid') or contains(text(),'error') or contains(text(),'incorrect')]"))
        ));

        // =====================================================
        // PHASE 5: Verify System Handles Input Without Crashing
        // =====================================================

        // Step 13: Verify that the system handles the long input without crashing
        // The page should still be functional (not crashed, no error page)
        boolean noCrash = driver.findElements(By.cssSelector(".error-page, .exception, .server-error")).isEmpty();
        Assert.assertTrue(noCrash,
                "System should handle very long input without crashing. No error page or exception should be displayed.");

        boolean pageStillFunctional = driver.getTitle() != null && !driver.getTitle().isEmpty();
        Assert.assertTrue(pageStillFunctional,
                "Application should remain functional after attempting login with very long input");

        // Step 14: Verify that no JavaScript alert dialog appears (no unexpected side effects)
        Assert.assertFalse(loginPage.isJavaScriptAlertPresent(),
                "No JavaScript alert dialog should appear after attempting login with very long input");

        // Step 15: Verify that authentication is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 16: Verify that the error message is displayed
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt with very long input");

        // Step 17: Verify that the displayed error message equals "Invalid Username"
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, EXPECTED_ERROR_MESSAGE,
                "Error message should indicate invalid username. Actual message: " + errorMessage);

        // Step 18: Verify that the user remains unauthenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in after failed login attempt with very long input");

        // Step 19: Verify that the Login modal remains open (or Sign In button still visible)
        // The application should recover gracefully and remain usable
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");

        // Step 20: Verify that the Product Listing page remains accessible as a guest user
        // The application should be fully functional after the test
        driver.get("https://bstackdemo.com/");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".shelf-container")));
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain accessible as a guest user after very long input test");
    }

    // =========================
    // TC_058 - Login with Locked User Account
    // =========================

    @Test
    public void tc058_loginWithLockedUserAccount() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // Test data: locked user credentials
        final String LOCKED_USERNAME = "locked_user";
        final String LOCKED_PASSWORD = "testingisfun99";
        final String EXPECTED_ERROR_MESSAGE = "Your account has been locked.";

        // =====================================================
        // PHASE 1: Verify Initial State (Pre-Login)
        // =====================================================

        // Step 1: Launch the BrowserStack Demo application
        // (Handled by BaseTest.setUp() which navigates to https://bstackdemo.com/)

        // Step 2: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 3: Verify that the Sign In button is visible
        // The signin link should be visible when user is not logged in
        Assert.assertTrue(loginPage.isLoggedOut(),
                "Sign In button should be visible before login (user should be logged out)");

        // =====================================================
        // PHASE 2: Open Login Modal
        // =====================================================

        // Step 4: Click the Sign In button
        loginPage.clickSignIn();

        // Step 5: Wait until the Login modal is displayed
        // The clickSignIn() method already waits for the signin form to be visible
        Assert.assertTrue(loginPage.isDisplayed(),
                "Login modal/page should be displayed after clicking Sign In");

        // =====================================================
        // PHASE 3: Enter Locked User Credentials
        // =====================================================

        // Step 6: Verify that the Username field is visible
        // Wait for the username dropdown to be visible and interactive
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement usernameDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        Assert.assertTrue(usernameDropdown.isDisplayed(),
                "Username dropdown should be visible on the login page");

        // Step 7: Enter the username: locked_user
        loginPage.selectUsername(LOCKED_USERNAME);

        // Step 8: Verify that the Password field is visible
        // Wait for the password dropdown to be visible and interactive
        WebElement passwordDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        Assert.assertTrue(passwordDropdown.isDisplayed(),
                "Password dropdown should be visible on the login page");

        // Step 9: Enter the password: testingisfun99
        loginPage.selectPassword(LOCKED_PASSWORD);

        // Step 10: Verify that the Login button is enabled
        // The login button should be clickable after selecting credentials
        By loginButtonLocator = By.id("login-btn");
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(loginButtonLocator));
        Assert.assertTrue(loginButton.isEnabled(),
                "Login button should be enabled on the login page");

        // =====================================================
        // PHASE 4: Attempt Login with Locked Account
        // =====================================================

        // Step 11: Click the Login button
        // Use clickLoginButtonWithoutWait() because locked account login will be rejected
        loginPage.clickLoginButtonWithoutWait();

        // Step 12: Wait for the authentication response
        // Wait for the error message to appear
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".error-message, .alert-danger, .invalid-feedback, [class*='error'], [class*='alert']")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'locked') or contains(text(),'error') or contains(text(),'account')]"))
        ));

        // =====================================================
        // PHASE 5: Verify Login Rejection
        // =====================================================

        // Step 13: Verify that authentication is rejected
        // The user should remain on the signin page (URL should still contain /signin)
        String currentUrl = driver.getCurrentUrl();
        String urlPath = currentUrl.replaceAll("\\?.*$", "");
        boolean stillOnSigninPage = urlPath.contains("/signin");
        Assert.assertTrue(stillOnSigninPage,
                "Login should be rejected and user should remain on signin page. Current URL: " + currentUrl);

        // Step 14: Verify that the error message is displayed
        Assert.assertTrue(loginPage.isLoginErrorDisplayed(),
                "Error message should be displayed after failed login attempt with locked account");

        // Step 15: Verify that the displayed message exactly equals: "Your account has been locked."
        String errorMessage = loginPage.getLoginErrorMessage();
        Assert.assertFalse(errorMessage.isEmpty(),
                "Error message should be displayed after failed login attempt");
        Assert.assertEquals(errorMessage, EXPECTED_ERROR_MESSAGE,
                "Error message should indicate locked account. Actual message: " + errorMessage);

        // Step 16: Verify that the user is not authenticated
        Assert.assertFalse(loginPage.isLoggedIn(),
                "User should not be logged in with locked account");

        // Step 17: Verify that the Sign In interface remains available
        // The signin form should still be visible after failed login
        Assert.assertTrue(loginPage.isLoginModalDisplayed() || loginPage.isSignInButtonVisible(),
                "Login modal should remain open or Sign In button should still be visible after failed login attempt");
    }
}
