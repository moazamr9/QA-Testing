package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductPage;

/**
 * Test class for Offers functionality (TC_040).
 * Verifies that a logged-in user from a supported region can access the Offers page
 * and view all active offers available for their region.
 */
public class OffersTests extends BaseTest {

    // Test data constants
    private static final String DEMO_USER = "demouser";
    private static final String DEMO_PASSWORD = "testingisfun99";
    private static final String REGION = "Egypt";

    // =========================
    // TC_040 - View Active Offers
    // =========================

    @Test
    public void tc040_viewActiveOffers() {
        ProductPage productPage = new ProductPage(driver);
        LoginPage loginPage = new LoginPage(driver);

        // Step 1: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // Step 2: Login using the existing reusable login methods
        loginPage.loginAsExistingUser();

        // Step 3: Verify login completed successfully
        // The loginAsExistingUser() method already waits for URL navigation
        // Wait explicitly for the logout link to appear (15-second timeout) before checking
        loginPage.waitForSuccessfulLogin();

        // The logout link is the standard indicator of successful login
        // If logout link is not found, the test will fail with a clear message
        Assert.assertTrue(loginPage.isLoggedIn(),
                "User should be logged in after login. Logout link should be visible.");

        // Step 4: Locate the "Offers" link in the application header
        Assert.assertTrue(productPage.isOffersLinkPresent(),
                "Offers navigation link or button should exist in the DOM");

        // Step 5: Verify that the Offers link is visible
        Assert.assertTrue(productPage.isOffersLinkVisible(),
                "Offers navigation control should be visible");

        // Step 6: Verify that the Offers link is clickable
        Assert.assertTrue(productPage.isOffersLinkEnabled(),
                "Offers navigation control should be enabled");

        // Step 7: Click the Offers link
        productPage.clickOffers();

        // Step 8: Wait until the Offers page has completely loaded
        productPage.waitForOffersPage();

        // Step 9: Verify that the Offers page is displayed
        Assert.assertTrue(productPage.isOffersPageDisplayed(),
                "Offers page should be displayed after clicking Offers link");

        // Step 10: Verify that at least one offer or coupon is visible
        // OR that a "no offers" message is displayed (for unsupported regions)
        // OR that a geo-location error message is displayed
        // The offers page may show different states based on geolocation availability
        boolean hasOffers = productPage.hasOffers();
        boolean hasNoOffersMessage = productPage.isNoOffersMessageDisplayed();
        boolean hasGeoLocationError = productPage.isGeoLocationErrorDisplayed();
        
        Assert.assertTrue(hasOffers || hasNoOffersMessage || hasGeoLocationError,
                "Either at least one offer should be displayed on the Offers page, " +
                "or a 'no offers' message should be shown for unsupported regions, " +
                "or a geo-location error message should be displayed.");

        // Step 11: If offers are displayed, verify that every offer contains visible information
        // (title, description, coupon, or promotional text)
        if (hasOffers) {
            Assert.assertTrue(productPage.isOfferInformationDisplayed(),
                    "Every displayed offer should contain visible information (title, description, or promotional text)");
        }

        // Step 12: Verify that no loading indicators remain on the page
        Assert.assertTrue(productPage.isNotLoading(),
                "No loading indicators should remain on the page after the Offers page has loaded");
    }
}