package tests;

import base.BaseTest;
import base.NetworkManager;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

public class CartTests extends BaseTest {

    private static final String IPHONE_12 = "iPhone 12";
    private static final String IPHONE_11 = "iPhone 11";
    private static final String IPHONE_4 = "iPhone 4";
    private static final String GALAXY_S20 = "Galaxy S20";
    private static final String GALAXY_NOTE_20 = "Galaxy Note 20";
    private static final String PIXEL_4 = "Pixel 4";
    private static final String IPHONE_XR = "iPhone XR";
    private static final String IPHONE_12_PRICE = "$799.00";

    // =========================
    // TC_001 - Add Product to Cart
    // =========================

    @Test
    public void tc001_addProductToCart() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);

        Assert.assertEquals(productPage.getCartBadgeCount(), 1);
    }

    // =========================
    // TC_002 - Add Same Product Twice
    // =========================

    @Test
    public void tc002_addSameProductTwice() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.addProductToCart(IPHONE_12);

        Assert.assertEquals(productPage.getCartBadgeCount(), 2);
    }

    // =========================
    // TC_003 - Subtotal Calculation
    // =========================

    @Test
    public void tc003_subtotalCalculation() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.addProductToCart(IPHONE_11);

        Assert.assertEquals(productPage.getCartSubtotal(), 1398);
    }

    // =========================
    // TC_004 - Add Multiple Products
    // =========================

    @Test
    public void tc004_addMultipleProducts() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_11);
        productPage.addProductToCart(IPHONE_12);
        productPage.addProductToCart(GALAXY_S20);
        productPage.addProductToCart(PIXEL_4);

        Assert.assertTrue(productPage.isProductDisplayedInCart(IPHONE_11));
        Assert.assertTrue(productPage.isProductDisplayedInCart(IPHONE_12));
        Assert.assertTrue(productPage.isProductDisplayedInCart(GALAXY_S20));
        Assert.assertTrue(productPage.isProductDisplayedInCart(PIXEL_4));
    }

    // =========================
    // TC_005 - Add Product Without Signing In
    // =========================

    @Test
    public void tc005_addProductWithoutSigningIn() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(GALAXY_S20);

        Assert.assertTrue(productPage.isProductDisplayedInCart(GALAXY_S20));
    }

    // =========================
    // TC_006 - Add Without Internet
    // =========================

    @Test
    public void tc006_addWithoutInternet() {
        ProductPage productPage = new ProductPage(driver);

        try {
            NetworkManager.goOffline(driver);

            productPage.addProductToCart(IPHONE_11);

            Assert.assertFalse(productPage.isProductDisplayedInCart(IPHONE_11));
        } finally {
            NetworkManager.goOnline(driver);
        }
    }

    // =========================
    // TC_007 - Add Product That Does Not Exist
    // =========================

    @Test
    public void tc007_addProductThatDoesNotExist() {
        ProductPage productPage = new ProductPage(driver);

        boolean productAvailable = productPage.isProductAvailable(IPHONE_4);
        boolean productDisplayedInCart = productPage.isProductDisplayedInCart(IPHONE_4);

        Assert.assertFalse(productAvailable);
        Assert.assertFalse(productDisplayedInCart);
    }

    // =========================
    // TC_008 - Remove Product From Cart
    // =========================

    @Test
    public void tc008_removeProductFromCart() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_XR);
        productPage.removeProductFromCart(IPHONE_XR);

        Assert.assertFalse(productPage.isProductDisplayedInCart(IPHONE_XR));
    }

    // =========================
    // TC_009 - Verify Empty Cart State
    // =========================

    @Test
    public void tc009_verifyEmptyCartState() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_XR);
        productPage.removeProductFromCart(IPHONE_XR);

        Assert.assertTrue(productPage.isCartEmpty());
    }

    // =========================
    // TC_010 - Subtotal Update After Remove
    // =========================

    @Test
    public void tc010_subtotalUpdateAfterRemove() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.addProductToCart(IPHONE_11);
        productPage.removeProductFromCart(IPHONE_12);
        productPage.removeProductFromCart(IPHONE_11);

        Assert.assertTrue(productPage.isCartEmpty());
        Assert.assertEquals(productPage.getCartSubtotal(), 0);
    }

    // =========================
    // TC_011 - Remove From Empty Cart
    // =========================

    @Test
    public void tc011_removeFromEmptyCart() {
        ProductPage productPage = new ProductPage(driver);

        productPage.openCart();

        Assert.assertTrue(productPage.isCartEmpty());
        Assert.assertFalse(productPage.isProductDisplayedInCart(IPHONE_12));
    }

    // =========================
    // TC_012 - Increase Quantity
    // =========================

    @Test
    public void tc012_increaseQuantity() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.openCart();
        productPage.increaseProductQuantity(IPHONE_12);

        Assert.assertEquals(productPage.getProductQuantity(IPHONE_12), 2);
        Assert.assertEquals(productPage.getCartSubtotal(), 1598);
    }

    // =========================
    // TC_013 - Decrease Quantity
    // =========================

    @Test
    public void tc013_decreaseQuantity() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.openCart();
        productPage.increaseProductQuantity(IPHONE_12);
        productPage.decreaseProductQuantity(IPHONE_12);

        Assert.assertEquals(productPage.getProductQuantity(IPHONE_12), 1);
        Assert.assertEquals(productPage.getCartSubtotal(), 799);
    }

    // =========================
    // TC_014 - Change Subtotal
    // =========================

    @Test
    public void tc014_changeSubtotal() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.openCart();

        productPage.increaseProductQuantity(IPHONE_12);
        Assert.assertEquals(productPage.getCartSubtotal(), 1598);

        productPage.decreaseProductQuantity(IPHONE_12);
        Assert.assertEquals(productPage.getCartSubtotal(), 799);
    }

    // =========================
    // TC_015 - Quantity Below One
    // =========================

    @Test
    public void tc015_quantityBelowOne() {
        ProductPage productPage = new ProductPage(driver);

        productPage.addProductToCart(IPHONE_12);
        productPage.openCart();

        Assert.assertEquals(productPage.getProductQuantity(IPHONE_12), 1);
        Assert.assertTrue(productPage.isDecreaseButtonDisabled(IPHONE_12));
        Assert.assertEquals(productPage.getProductQuantity(IPHONE_12), 1);
        Assert.assertEquals(productPage.getCartSubtotal(), 799);
        Assert.assertTrue(productPage.isProductDisplayedInCart(IPHONE_12));
    }

    // =========================
    // TC_017 - Product Name Validation
    // =========================

    @Test
    public void tc017_productNameValidation() {
        ProductPage productPage = new ProductPage(driver);

        String actualProductName = productPage.getProductTitle(GALAXY_NOTE_20);

        Assert.assertEquals(actualProductName, GALAXY_NOTE_20);
    }

    // =========================
    // TC_018 - Price & Currency Check
    // =========================

    @Test
    public void tc018_priceAndCurrencyCheck() {
        ProductPage productPage = new ProductPage(driver);

        String displayedPrice = productPage.getProductPrice(IPHONE_12);
        String currencySymbol = productPage.getProductCurrencySymbol(IPHONE_12);

        Assert.assertEquals(displayedPrice, IPHONE_12_PRICE);
        Assert.assertEquals(currencySymbol, "$" );
        Assert.assertTrue(productPage.isPriceFormattedWithTwoDecimals(displayedPrice));
        Assert.assertTrue(productPage.isDisplayedPriceExpected(IPHONE_12, IPHONE_12_PRICE));
    }

    // =========================
    // TC_019 - EMI Accuracy
    // =========================

    @Test
    public void tc019_emiAccuracy() {
        ProductPage productPage = new ProductPage(driver);

        Assert.assertTrue(productPage.isEmiAmountConsistent(IPHONE_12));
        Assert.assertTrue(productPage.isEmiAmountConsistent(GALAXY_S20));
    }

    // =========================
    // TC_020 - Contextual Search
    // =========================

    @Test
    public void tc020_contextualSearch() {
        ProductPage productPage = new ProductPage(driver);

        productPage.searchForProduct(IPHONE_12);

        Assert.assertTrue(productPage.isProductVisible(IPHONE_12));
        Assert.assertTrue(productPage.isOnlyMatchingProductsDisplayed(IPHONE_12));
    }

    // =========================
    // TC_021 - Breadcrumb Navigation
    // =========================

    @Test
    public void tc021_breadcrumbNavigation() {
        ProductPage productPage = new ProductPage(driver);

        productPage.navigateToHome();

        Assert.assertTrue(productPage.isHomePageDisplayed());
    }

}
