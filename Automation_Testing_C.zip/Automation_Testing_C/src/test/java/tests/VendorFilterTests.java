package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * Test class for Vendor Filter functionality.
 * TC_025: Filter by single vendor (Apple).
 * TC_026: Filter by multiple vendors (Apple + Samsung).
 * TC_027: Filter persistence after page refresh (Apple).
 * TC_028: Clear filters and verify all products are displayed.
 * TC_036: Product Counter Accuracy.
 * Uses count-based synchronization, avoiding staleness assumptions
 * that are incompatible with React's DOM reuse behavior.
 */
public class VendorFilterTests extends BaseTest {

    private static final String VENDOR_APPLE = "Apple";
    private static final String VENDOR_SAMSUNG = "Samsung";
    private static final String VENDOR_GOOGLE = "Google";
    private static final String VENDOR_ONEPLUS = "OnePlus";

    // =========================
    // TC_025 – Filter by Single Vendor
    // =========================

    @Test
    public void tc025_filterBySingleVendor() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Open BrowserStack Demo
        // (Handled by BaseTest.setUp())

        // 2. Wait for initial products to load and record the count
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed on initial load");

        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before filtering");

        // 3. Select the Apple vendor filter
        productPage.clickVendorFilter(VENDOR_APPLE);

        // 4. Wait for the filtering operation to complete.
        //    Using count-based synchronization (Option 1 - Preferred):
        //    React reuses DOM elements instead of destroying them,
        //    so staleness-based waiting would fail.
        //    Instead, we wait until the visible product count changes.
        productPage.waitForFilterToComplete(initialVisibleCount);

        // 5. Verify that at least one product is displayed after filtering
        int afterFilterCount = productPage.getVisibleProductCount();
        Assert.assertTrue(afterFilterCount > 0,
                "At least one product should be displayed after applying Apple filter");

        // 6. Verify that every visible product belongs to Apple
        Assert.assertTrue(productPage.areAllVisibleProductsFromVendor(VENDOR_APPLE),
                "All visible products should belong to Apple after applying Apple filter");

        // 7. Verify that no Samsung products are visible
        Assert.assertEquals(productPage.getVisibleProductCountForVendor(VENDOR_SAMSUNG), 0,
                "No Samsung products should be visible after applying Apple filter");

        // 8. Verify that no Google products are visible
        Assert.assertEquals(productPage.getVisibleProductCountForVendor(VENDOR_GOOGLE), 0,
                "No Google products should be visible after applying Apple filter");

        // 9. Verify that no OnePlus products are visible
        Assert.assertEquals(productPage.getVisibleProductCountForVendor(VENDOR_ONEPLUS), 0,
                "No OnePlus products should be visible after applying Apple filter");
    }

    // =========================
    // TC_026 – Filter by Multiple Vendors (Apple + Samsung)
    // =========================

    @Test
    public void tc026_filterByMultipleVendors() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Open BrowserStack Demo
        // (Handled by BaseTest.setUp())

        // 2. Verify product listing page loaded
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed on initial load");

        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before filtering");

        // 3. Select the Apple vendor filter
        productPage.clickVendorFilter(VENDOR_APPLE);

        // 4. Wait for Apple filtering to fully complete.
        //    Uses waitForVendorFilterApplied() instead of waitForFilterToComplete()
        //    because count-based waiting can return before React has finished rendering.
        //    This method waits for:
        //    a) The Apple checkbox to become selected (confirms React processed the click)
        //    b) All visible products to be from Apple (confirms rendering is complete)
        productPage.waitForVendorFilterApplied(VENDOR_APPLE, Arrays.asList(VENDOR_APPLE));

        // 5. Record the count after Apple filter
        int afterAppleCount = productPage.getVisibleProductCount();

        // 6. Select the Samsung vendor filter
        productPage.clickVendorFilter(VENDOR_SAMSUNG);

        // 7. Wait for Samsung filtering to fully complete.
        //    Both Apple and Samsung should now be visible.
        productPage.waitForVendorFilterApplied(VENDOR_SAMSUNG, Arrays.asList(VENDOR_APPLE, VENDOR_SAMSUNG));

        // 8. Verify filtering completed and at least one product is displayed
        int finalCount = productPage.getVisibleProductCount();
        Assert.assertTrue(finalCount > 0,
                "At least one product should be displayed after applying Apple and Samsung filters");

        // 9. Verify that every visible product belongs to Apple or Samsung only
        List<String> allowedVendors = Arrays.asList(VENDOR_APPLE, VENDOR_SAMSUNG);
        Assert.assertTrue(productPage.areAllVisibleProductsOnlyFromVendors(allowedVendors),
                "All visible products should belong to Apple or Samsung only");

        // 10. Verify that products from Apple exist
        long appleCount = productPage.getVisibleProductCountForVendor(VENDOR_APPLE);
        Assert.assertTrue(appleCount > 0,
                "Products from Apple should be present after applying Apple and Samsung filters");

        // 11. Verify that products from Samsung exist
        long samsungCount = productPage.getVisibleProductCountForVendor(VENDOR_SAMSUNG);
        Assert.assertTrue(samsungCount > 0,
                "Products from Samsung should be present after applying Apple and Samsung filters");

        // 12. Verify that no Google products are displayed
        Assert.assertEquals(productPage.getVisibleProductCountForVendor(VENDOR_GOOGLE), 0,
                "No Google products should be visible after applying Apple and Samsung filters");

        // 13. Verify that no OnePlus products are displayed
        Assert.assertEquals(productPage.getVisibleProductCountForVendor(VENDOR_ONEPLUS), 0,
                "No OnePlus products should be visible after applying Apple and Samsung filters");

        // 14. Double-check using vendor set extraction that both Apple and Samsung are present
        Set<String> visibleVendors = productPage.getVisibleProductVendors();
        Assert.assertTrue(visibleVendors.contains(VENDOR_APPLE),
                "Apple must be among the visible vendors");
        Assert.assertTrue(visibleVendors.contains(VENDOR_SAMSUNG),
                "Samsung must be among the visible vendors");
        Assert.assertEquals(visibleVendors.size(), 2,
                "Only Apple and Samsung vendors should be present, but found: " + visibleVendors);
    }

    // =========================
    // TC_027 – Filter Persistence After Page Refresh
    // =========================

    @Test
    public void tc027_filterPersistenceAfterRefresh() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the product listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed on initial load");

        // 2. Apply the Apple vendor filter
        productPage.clickVendorFilter(VENDOR_APPLE);

        // 3. Wait until filtering has completely finished
        productPage.waitForVendorFilterApplied(VENDOR_APPLE, Arrays.asList(VENDOR_APPLE));

        int beforeRefreshCount = productPage.getVisibleProductCount();
        Assert.assertTrue(beforeRefreshCount > 0,
                "At least one product should be displayed after applying Apple filter");

        // 4. Verify that only Apple products are visible before refresh
        Assert.assertTrue(productPage.areAllVisibleProductsFromVendor(VENDOR_APPLE),
                "All visible products should belong to Apple before page refresh");

        // 5. Refresh the browser using Selenium
        productPage.refreshPage();

        // 6. Wait until the page has fully reloaded
        productPage.waitForPageReload();

        // 7. Verify whether the Apple filter remains selected after refresh
        Assert.assertTrue(productPage.isVendorFilterSelected(VENDOR_APPLE),
                "Apple filter should remain selected after page refresh");

        // 8. Verify whether only Apple products are still displayed after refresh
        Assert.assertTrue(productPage.areAllVisibleProductsFromVendor(VENDOR_APPLE),
                "All visible products should belong to Apple after page refresh");
    }

    // =========================
    // TC_029 – Filter with No Result (Invalid Vendor "XYZ")
    // =========================

    @Test
    public void tc029_filterWithNoResult() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify the Product Listing page has loaded successfully
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed on initial load");

        // 2. Verify that vendor "XYZ" is NOT present in the available vendor filters
        Assert.assertFalse(productPage.isVendorPresent("XYZ"),
                "Vendor 'XYZ' should not be present in the available vendor filters");

        // 3. Attempt to select the non-existent vendor "XYZ"
        //    This should return false without throwing an exception
        boolean selectionResult = productPage.attemptToSelectVendor("XYZ");
        Assert.assertFalse(selectionResult,
                "Attempting to select non-existent vendor 'XYZ' should return false");

        // 4. Verify the application did not crash and is still responsive
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should still be displayed after attempting invalid vendor filter");

        // 5. Verify the application's graceful behavior:
        //    - Record the current product count (should be unchanged since no filter was applied)
        int visibleProductCount = productPage.getVisibleProductCount();

        //    - Check if the product grid is empty or shows a "No Products Found" message
        boolean gridEmpty = productPage.isProductGridEmpty();
        boolean noProductsMessage = productPage.isNoProductsMessageDisplayed();

        //    - Report the actual application behavior without modifying it
        if (gridEmpty) {
            Assert.assertTrue(noProductsMessage,
                    "When product grid is empty after invalid filter, a 'No Products Found' message should be displayed");
            Assert.assertEquals(visibleProductCount, 0,
                    "Product count should be 0 when grid is empty");
        } else {
            // The application ignored the invalid vendor request and shows all products
            Assert.assertTrue(visibleProductCount > 0,
                    "Products should still be visible when application ignores invalid vendor filter");
        }

        // 6. Verify that no products matching "XYZ" are displayed
        //    (XYZ is not a known vendor, so getVendorKeyword returns "XYZ" as-is)
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("XYZ"), 0,
                "No products matching vendor 'XYZ' should be displayed");
    }

    // =========================
    // TC_030 – Sorting While Filtering
    // =========================

    @Test
    public void tc030_sortingWhileFiltering() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page has loaded successfully
        productPage.waitForProductListing();
        Assert.assertTrue(productPage.getVisibleProductCount() > 0,
                "Products should be displayed on the product listing page");

        // 2. Record the initial visible product count before sorting
        int countBeforeSort = productPage.getVisibleProductCount();

        // 3. Locate the Sort control and select the Price sorting option
        productPage.selectSortingOption("Lowest to highest");

        // 4. Wait for the sorting operation to complete
        productPage.waitForSortingToComplete();

        // 5. Verify that the prices are displayed in the correct sorted order
        Assert.assertTrue(productPage.arePricesSortedAscending(),
                "Product prices should be sorted in ascending order after selecting 'Lowest to highest'");

        // 6. Verify that the product count remains unchanged after sorting
        int countAfterSort = productPage.getVisibleProductCount();
        Assert.assertEquals(countAfterSort, countBeforeSort,
                "Product count after sorting should match the count before sorting");
    }

    // =========================
    // TC_028 – Clear Filters by toggling the Apple filter off
    // =========================
    // Preconditions:
    //   - Home page is loaded
    // Steps:
    //   1. Verify product listing page is displayed
    //   2. Record the initial visible product count (all products)
    //   3. Apply the Apple vendor filter
    //   4. Wait for filter to complete
    //   5. Click the Apple filter again to remove it (toggle off)
    //   6. Wait for filters to be cleared
    //   7. Verify the product count matches the initial count before filtering
    // Expected Result: Filters are cleared and all products are shown

    @Test
    public void tc028_clearFilters() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the product listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed on initial load");

        // 2. Record the initial visible product count (all products)
        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before applying the filter");

        // 3. Apply the Apple vendor filter
        productPage.clickVendorFilter(VENDOR_APPLE);

        // 4. Wait for the Apple filter to be fully applied
        productPage.waitForVendorFilterApplied(VENDOR_APPLE, Arrays.asList(VENDOR_APPLE));

        // 5. Click the Apple filter again to remove it (toggle off)
        productPage.clickVendorFilter(VENDOR_APPLE);

        // 6. Wait for filters to be cleared (products from multiple vendors should appear)
        productPage.waitForClearFilterToComplete();

        // 7. Verify the product count matches the initial count before filtering
        int afterClearCount = productPage.getVisibleProductCount();
        Assert.assertEquals(afterClearCount, initialVisibleCount,
                "Product count after toggling off the Apple filter should match the initial count before filtering");
    }

    // =========================
    // TC_036 – Product Counter Accuracy
    // =========================

    @Test
    public void tc036_productCounterAccuracy() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Verify that the vendor filter section is visible
        Assert.assertTrue(productPage.isVendorPresent(VENDOR_SAMSUNG),
                "Samsung vendor filter should be present in the filter options");

        // 3. Apply the Samsung vendor filter
        productPage.clickVendorFilter(VENDOR_SAMSUNG);

        // 4. Wait until filtering has completely finished using the existing synchronization strategy
        productPage.waitForVendorFilterApplied(VENDOR_SAMSUNG, Arrays.asList(VENDOR_SAMSUNG));

        // 5. Read the product counter label displayed by the application
        String counterText = productPage.getProductCounterText();

        // 6. Verify that the product counter label is displayed
        Assert.assertFalse(counterText.isEmpty(),
                "Product counter label should be displayed after applying filter");

        // 7. Verify that the counter text contains a valid numeric value
        int displayedCount = productPage.getDisplayedProductCount();
        Assert.assertTrue(displayedCount > 0,
                "Counter should contain a valid numeric value greater than zero. Found: '" + counterText + "'");

        // 8. Count the number of visible product cards currently displayed
        int actualVisibleCount = productPage.getVisibleProductCount();

        // 9. Verify that actual visible product count is greater than zero
        Assert.assertTrue(actualVisibleCount > 0,
                "At least one product should be visible after applying Samsung filter");

        // 10. Verify that only Samsung products are visible
        Assert.assertTrue(productPage.areAllVisibleProductsFromVendor(VENDOR_SAMSUNG),
                "All visible products should belong to Samsung after applying Samsung filter");

        // 11. Compare both values - the displayed counter value must equal the actual number of visible product cards
        Assert.assertEquals(displayedCount, actualVisibleCount,
                "Displayed counter value (" + displayedCount + ") must equal the actual number of visible product cards (" + actualVisibleCount + ")");
    }
}