package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

import java.util.List;

/**
 * Test class for Search functionality.
 * TC_031: Basic Search
 * Verifies that searching with a valid keyword displays the expected matching products.
 * TC_032: Search for Non-Existent Item
 * Verifies that searching for a product that does not exist displays an appropriate empty-result state.
 * TC_033: Search with Special Characters
 * Verifies that the application correctly handles search input containing special characters.
 * TC_034: Case Insensitive Search
 * Verifies that the search functionality is case-insensitive by ensuring that searching with
 * uppercase letters returns the same results as searching with lowercase letters.
 */
public class SearchTests extends BaseTest {

    private static final String SEARCH_KEYWORD = "iPhone";
    private static final String EXPECTED_PRODUCT = "iPhone 12";
    private static final String SEARCH_KEYWORD_NONEXISTENT = "abcxyz";
    private static final String SEARCH_KEYWORD_SPECIAL_CHARS = "@#$%";
    private static final String SEARCH_KEYWORD_LOWERCASE = "iphone";
    private static final String SEARCH_KEYWORD_UPPERCASE = "IPHONE";

    // =========================
    // TC_031 – Basic Search
    // =========================

    @Test
    public void tc031_basicSearch() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page has loaded successfully
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Locate the search input field
        // (Handled by searchForProduct method which waits for element to be clickable)

        // 3. Record the initial visible product count before search
        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before search");

        // 4. Enter the keyword: iPhone
        productPage.searchForProduct(SEARCH_KEYWORD);

        // 5. Click the Search button (or trigger the search using the application's supported mechanism)
        productPage.clickSearchButton();

        // 6. Wait until the search operation completes and the product grid finishes rendering
        productPage.waitForSearchToComplete(initialVisibleCount);

        // 7. Verify that the search results are displayed
        int searchResultsCount = productPage.getVisibleProductCount();
        Assert.assertTrue(searchResultsCount > 0,
                "Search results should be displayed after searching for 'iPhone'");

        // 8. Verify that all displayed products are relevant to the search keyword
        Assert.assertTrue(productPage.areAllVisibleProductsMatchingKeyword(SEARCH_KEYWORD),
                "All displayed products should contain the keyword 'iPhone' in their title");

        // 9. Verify that "iPhone 12" appears in the results
        Assert.assertTrue(productPage.isProductVisible(EXPECTED_PRODUCT),
                "iPhone 12 should be visible in the search results");

    // 10. Verify that unrelated products are not displayed
    // Check that no products from other vendors (Samsung, Google, OnePlus) are visible
    Assert.assertEquals(productPage.getVisibleProductCountForVendor("Samsung"), 0,
            "No Samsung products should be visible after searching for 'iPhone'");
    Assert.assertEquals(productPage.getVisibleProductCountForVendor("Google"), 0,
            "No Google products should be visible after searching for 'iPhone'");
    Assert.assertEquals(productPage.getVisibleProductCountForVendor("OnePlus"), 0,
            "No OnePlus products should be visible after searching for 'iPhone'");
    }

    // =========================
    // TC_032 – Search for Non-Existent Item
    // =========================

    @Test
    public void tc032_searchForNonExistentItem() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page has loaded successfully
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Verify that the search input field is visible and ready for interaction
        Assert.assertTrue(productPage.isSearchInputVisible(),
                "Search input field should be visible and ready for interaction");

        // 3. Record the initial visible product count before search
        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before search");

        // 4. Enter the keyword: abcxyz
        productPage.searchForProduct(SEARCH_KEYWORD_NONEXISTENT);

        // 5. Click the Search button (or trigger the search using the application's supported mechanism)
        productPage.clickSearchButton();

        // 6. Wait until the search operation has completely finished
        productPage.waitForSearchToComplete(initialVisibleCount);

        // 7. Wait until React finishes rendering the updated product list
        productPage.waitForReactRenderComplete();

        // 8. Verify that no matching products are displayed
        int visibleProductCount = productPage.getVisibleProductCount();
        Assert.assertEquals(visibleProductCount, 0,
                "Zero matching products should be displayed after searching for non-existent item 'abcxyz'");

        // 9. Verify that an empty-result message (or equivalent "No Products Found" message) is displayed
        Assert.assertTrue(productPage.isNoResultsMessageDisplayed(),
                "A 'No Results' or equivalent empty-state message should be displayed");

        // 10. Verify that unrelated products are not displayed
        // Check that no products from any known vendor are visible
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Apple"), 0,
                "No Apple products should be visible after searching for non-existent item 'abcxyz'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Samsung"), 0,
                "No Samsung products should be visible after searching for non-existent item 'abcxyz'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Google"), 0,
                "No Google products should be visible after searching for non-existent item 'abcxyz'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("OnePlus"), 0,
                "No OnePlus products should be visible after searching for non-existent item 'abcxyz'");

    // 11. Verify that the application remains stable throughout the search operation
    Assert.assertTrue(productPage.isProductListingDisplayed(),
            "Product Listing page should remain stable and displayed after search operation");
    }

    // =========================
    // TC_033 – Search with Special Characters
    // =========================

    @Test
    public void tc033_searchWithSpecialCharacters() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page has loaded successfully
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Verify that the search input field is visible and ready for interaction
        Assert.assertTrue(productPage.isSearchInputVisible(),
                "Search input field should be visible and ready for interaction");

        // 3. Record the initial visible product count before search
        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before search");

        // 4. Enter the search keyword: @#$%
        productPage.searchForProduct(SEARCH_KEYWORD_SPECIAL_CHARS);

        // 5. Click the Search button (or trigger the search using the application's supported mechanism)
        productPage.clickSearchButton();

        // 6. Wait until the search operation has completely finished
        productPage.waitForSearchToComplete(initialVisibleCount);

        // 7. Wait until React finishes rendering the updated product list
        productPage.waitForReactRenderComplete();

        // 8. Verify that the application remains stable after processing the input
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain stable and displayed after search operation");

        // 9. Verify that zero matching products are displayed
        int visibleProductCount = productPage.getVisibleProductCount();
        Assert.assertEquals(visibleProductCount, 0,
                "Zero matching products should be displayed after searching for special characters '@#$%'");

        // 10. Verify that an empty-result message (or equivalent) is displayed
        Assert.assertTrue(productPage.isNoResultsMessageDisplayed(),
                "A 'No Results' or equivalent empty-state message should be displayed for special character search");

        // 11. Verify that no unrelated products are displayed
        // Check that no products from any known vendor are visible
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Apple"), 0,
                "No Apple products should be visible after searching for special characters '@#$%'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Samsung"), 0,
                "No Samsung products should be visible after searching for special characters '@#$%'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("Google"), 0,
                "No Google products should be visible after searching for special characters '@#$%'");
        Assert.assertEquals(productPage.getVisibleProductCountForVendor("OnePlus"), 0,
                "No OnePlus products should be visible after searching for special characters '@#$%'");

        // 12. Verify that no unexpected UI errors occur
        // The page should be in a valid state (product listing displayed)
        Assert.assertTrue(productPage.isProductGridEmpty() || productPage.isNoResultsMessageDisplayed(),
                "The product grid should be empty or a no-results message should be displayed");
    }

    // =========================
    // TC_034 – Case Insensitive Search
    // =========================

    @Test
    public void tc034_caseInsensitiveSearch() {
        ProductPage productPage = new ProductPage(driver);

        // 1. Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed on initial load");

        // 2. Verify that the search input field is available
        Assert.assertTrue(productPage.isSearchInputVisible(),
                "Search input field should be visible and ready for interaction");

        // 3. Record the initial visible product count before any search
        int initialVisibleCount = productPage.getVisibleProductCount();
        Assert.assertTrue(initialVisibleCount > 0,
                "There should be visible products before search");

        // 4. Search for lowercase keyword: iphone
        productPage.searchForProduct(SEARCH_KEYWORD_LOWERCASE);

        // 5. Click the Search button
        productPage.clickSearchButton();

        // 6. Wait until the search results finish loading
        productPage.waitForSearchToComplete(initialVisibleCount);
        productPage.waitForReactRenderComplete();

        // 7. Capture the displayed search results (lowercase search)
        List<String> lowercaseResults = productPage.getVisibleProductTitles();
        int lowercaseResultCount = productPage.getVisibleProductCount();

        // Verify lowercase search returns results
        Assert.assertTrue(lowercaseResultCount > 0,
                "Lowercase search for 'iphone' should return results");

        // 8. Clear the search field and wait for all products to return
        productPage.searchForProduct("");
        productPage.waitForReactRenderComplete();

        // 9. Search for uppercase keyword: IPHONE
        productPage.searchForProduct(SEARCH_KEYWORD_UPPERCASE);

        // 10. Click the Search button
        productPage.clickSearchButton();

        // 11. Wait until the second search operation completes
        productPage.waitForSearchToComplete(initialVisibleCount);
        productPage.waitForReactRenderComplete();

        // 12. Capture the displayed search results (uppercase search)
        List<String> uppercaseResults = productPage.getVisibleProductTitles();
        int uppercaseResultCount = productPage.getVisibleProductCount();

        // Verify uppercase search returns results
        Assert.assertTrue(uppercaseResultCount > 0,
                "Uppercase search for 'IPHONE' should return results");

        // 13. Compare both result sets
        // Verify that both searches return the same number of products
        Assert.assertEquals(uppercaseResultCount, lowercaseResultCount,
                "Both searches should return the same number of products. " +
                "Lowercase search returned " + lowercaseResultCount + " products, " +
                "uppercase search returned " + uppercaseResultCount + " products");

        // Verify that both searches return identical product names
        Assert.assertEquals(uppercaseResults.size(), lowercaseResults.size(),
                "Both searches should return the same number of product titles");

        // Verify that the product names are identical (order matters)
        for (int i = 0; i < lowercaseResults.size(); i++) {
            Assert.assertEquals(uppercaseResults.get(i), lowercaseResults.get(i),
                    "Product at position " + (i + 1) + " should be the same in both searches. " +
                    "Lowercase: '" + lowercaseResults.get(i) + "', Uppercase: '" + uppercaseResults.get(i) + "'");
        }

        // Verify that no unexpected products appear in either search
        // All products should be from Apple vendor (iPhone products)
        Assert.assertTrue(productPage.areAllVisibleProductsMatchingKeyword("iphone"),
                "All displayed products should contain 'iphone' in their title (case-insensitive)");

        // Verify that the application remains stable throughout both searches
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should remain stable and displayed after both searches");
    }
}