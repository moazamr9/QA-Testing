package tests;

import base.BaseTest;
import org.openqa.selenium.Dimension;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

public class MobileUIAdaptationTests extends BaseTest {

    private static final String IPHONE_12 = "iPhone 12";
    private static final int MOBILE_VIEWPORT_WIDTH = 390;
    private static final int MOBILE_VIEWPORT_HEIGHT = 844;

    // =========================
    // TC_022 - Mobile UI Adaptation
    // =========================

    @Test
    public void tc022_mobileUIAdaptation() {
        ProductPage productPage = new ProductPage(driver);

        // Step 1: Verify that the Product Listing page has loaded
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product listing page should be displayed after launching the application");

        // Step 2: Resize the browser window to a mobile-sized viewport
        driver.manage().window().setSize(new Dimension(MOBILE_VIEWPORT_WIDTH, MOBILE_VIEWPORT_HEIGHT));

        // Step 3: Wait until the responsive layout has finished rendering
        Assert.assertTrue(productPage.isProductCardDisplayed(),
                "At least one product card should be displayed after resizing to mobile viewport");

        // Step 4: Verify that product title is visible
        Assert.assertTrue(productPage.isProductInformationVisible(IPHONE_12),
                "Product information (title and price) should be visible for " + IPHONE_12);

        // Step 5: Verify that product price is visible
        String productPrice = productPage.getProductPrice(IPHONE_12);
        Assert.assertNotNull(productPrice, "Product price should not be null");
        Assert.assertFalse(productPrice.isEmpty(), "Product price should not be empty");

        // Step 6: Verify that the "Add to Cart" button remains visible
        Assert.assertTrue(productPage.isAddToCartButtonVisible(IPHONE_12),
                "Add to Cart button should be visible for " + IPHONE_12);

        // Step 7: Verify that the "Add to Cart" button remains enabled
        Assert.assertTrue(productPage.isAddToCartButtonEnabled(IPHONE_12),
                "Add to Cart button should be enabled for " + IPHONE_12);

        // Step 8: Verify that no essential product information disappears after resizing
        String productTitle = productPage.getProductTitle(IPHONE_12);
        Assert.assertNotNull(productTitle, "Product title should not be null after resizing");
        Assert.assertFalse(productTitle.isEmpty(), "Product title should not be empty after resizing");
        Assert.assertEquals(productTitle, IPHONE_12,
                "Product title should match the expected product name after resizing");

        // Step 9: Confirm that the responsive layout is successfully displayed
        Assert.assertTrue(productPage.isResponsiveLayoutDisplayed(),
                "Responsive layout should be properly displayed with all essential elements visible and accessible");
    }
}