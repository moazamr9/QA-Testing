package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;

public class NavigationTests extends BaseTest {

    private static final String IPHONE_12_PRO = "iPhone 12 Pro";

    // =========================
    // TC_023 - Navigate to Product Details
    // =========================

    @Test
    public void tc023_navigateToProductDetails() {
        ProductPage productPage = new ProductPage(driver);

        // Step 1: Verify that the Product Listing page is displayed
        Assert.assertTrue(productPage.isProductListingDisplayed(),
                "Product Listing page should be displayed");

        // Step 2 & 3: Locate the product card and verify the product image is present and visible
        Assert.assertTrue(productPage.isProductImageVisible(IPHONE_12_PRO),
                "Product image for " + IPHONE_12_PRO + " should be visible");

        // Step 4: Verify the image is interactable (clickable)
        Assert.assertTrue(productPage.isProductImageClickable(IPHONE_12_PRO),
                "Product image for " + IPHONE_12_PRO + " should be clickable");

        // Step 5: Click the product image
        productPage.clickProductImage(IPHONE_12_PRO);

        // Step 6 & 7: Wait for navigation and verify that the Product Details page is displayed
        Assert.assertTrue(productPage.isProductDetailsPageDisplayed(),
                "Navigation to Product Details page for " + IPHONE_12_PRO + " should occur");
    }
}